<?php
/*Programozasi techikak lekerese az adatbazibol es meube lista irjuk ki*/
function getCategorie(){
    $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina');

    /* check connection */
    if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
    }

    $query = "SELECT categorieName,categorieId FROM categories ORDER by categorieId  LIMIT 5";

    if ($stmt = mysqli_prepare($link, $query)) {

        /* execute statement */
        mysqli_stmt_execute($stmt);

        /* bind result variables */
        mysqli_stmt_bind_result($stmt, $categorieName,$categorieId);

        /* fetch values */
        
        while (mysqli_stmt_fetch($stmt)) {
              echo '<li> <a href="programing_techinc.php?pageid='.$categorieId . '&pagename='. str_replace(' ','-',$categorieName).'">' . $categorieName.'</a></li>';
        }

        /* close statement */
        mysqli_stmt_close($stmt);
    }

    /* lezaas */
    mysqli_close($link);
}
/*Lekerjuk az adatbazisbol a logot*/
function getLogo(){
    
        $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina') or die($link->connect_errno);
        $result= $link->query('SELECT pictureNine FROM pictures where pictureName="logo"');
         
         while ($data = $result->fetch_assoc()) {
            echo "<img src= '{$data['pictureNine']}' width='250px' height='240px'>";
             
         }
        
}
/*A fooldalon megjeleniteni a szoveget es a regisztracio linket es a kepet is*/
function getHomePageRegistration(){
    $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina') or die($link->connect_errno);
        $result= $link->query('SELECT homepage.homepageDescript,pictures.pictureNine
         FROM pictures JOIN homepage ON pictures.homepageId = homepage.homepageId WHERE homepage.homepageName="fiok"');
         
         while ($data = $result->fetch_assoc()) {
            echo "<div class='homepage_disigne'>"; 
            echo "<img class='center' src='{$data['pictureNine']}' width='300px' height='300px'>";

             $text = str_replace('?','?<br>',$data['homepageDescript']);
             $text2= str_replace('Regisztrálj!','<a class="homeLink" href="register.php"><br>Regisztrálj</a>',$text);
            echo "<h2 class='text-homepage'>{$text2}</h2>";
             echo "</div>";   
             
         }
}
/*Lekernia a fooldalra a nyelvi ikonokat kepeket az adatbazisbol*/
function getProgramingLaunguageIcon(){

        $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina') or die($link->connect_errno);
        $result= $link->query('SELECT pictureNine FROM pictures where homepageId=2');
        $result2=$link->query('SELECT homepageDescript FROM `homepage` WHERE homepageName="nyelv_icon"');
        while ($data = $result2->fetch_assoc()) {
            $text = $data['homepageDescript'];
            echo "<h2 class='text-homepage'>{$text}</h2>";
        }

        while ($data = $result->fetch_assoc()) {
            echo "<div class='homepage_disigne2'>"; 
            echo "<img class='center' src='{$data['pictureNine']}' width='150px' height='150px'>";

            echo "</div>";   


        }
         
}

function p(){
    $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina') or die($link->connect_errno);
    $result=$link->query('SELECT langName,langCompilareInfo FROM prog_language ORDER by prog_langId  LIMIT 3');
    $data2=array();
    while ($data = $result->fetch_assoc()) {
     $text = $data['langCompilareInfo'];
     $data2[]= $text;
   
     
   

  
    }   
    echo json_encode($data2);
   
}
/*Lekerjuk azokat a feladatot a kategoriakhoz a programozasi technikakhoz*/

function getTaskTItem($id){
    $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina');

    /* check connection */
    if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
    }

    //$query = "SELECT taskTitle,task_id FROM tasks ORDER by task_id  LIMIT 5";
    $query=  $link->query("SELECT tasks.taskTitle,tasks.task_id,difficultylevel.LavelName FROM categories join tasks on categories.categorieId=tasks.categorieId  join difficultylevel on tasks.lavelId =difficultylevel.lavelId where categories.categorieId='$id'");

    
        while ($data = $query->fetch_assoc()) {
            $task_id=$data['task_id'];
            $taskTitle=$data['taskTitle'];
            $diffLavel = $data['LavelName'];

              echo '<div class="problem-link">'.$taskTitle.'<br><a class="diffLevlink"  href="dificultLevel.php?dificultLevel='.$diffLavel.'">'.$diffLavel.'</a><p class="probLinklem"><a class="solve-link" href="taskItem.php?pageid='.$task_id . '&pagename='. str_replace(' ','-',$taskTitle).'"><br>Megoldás most</a> </p></div>';
        }

        
    

    /* lezaas */
    mysqli_close($link);
}
function getTaskTItemShohwItem($id)
{
    $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina') or die($link->connect_errno);
    $query=  $link->query("SELECT tasks.taskTitle,tasks.taskText,categories.categorieName,difficultylevel.LavelName
     FROM categories join tasks on categories.categorieId=tasks.categorieId 
    join difficultylevel on tasks.lavelId =difficultylevel.lavelId where tasks.task_id='$id '");
    while ($data = $query->fetch_assoc()) {
        $taskT=$data['taskTitle'];
        $taskText=$data['taskText'];
        $categoriN=$data['categorieName'];
        $dificultL=$data['LavelName'];

        echo '<div><h2 class="text-center">'.$taskT.'</h2><br><h5 class="text-center" >Nehézségi szintje: '.$dificultL.'</h5><h3 class="text-md-left">'.$taskText.'</h3></div>';

    }


}
/*Input output dop down filter task*/

function dropdownTestTaskValue($id){
    $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina') or die($link->connect_errno);
    $query2=$link->query("SELECT testFileItem.testFileItemId,testFileItem.testFileItemName,testFileItem.testInputVelue,testFileItem.testOutputVelue
    FROM testFileItem join TaskAndTest on testFileItem.testFileItemId=TaskAndTest.testFileItemId 
    join tasks on tasks.task_id =TaskAndTest.task_id where tasks.task_id='$id '");
     $query=$link->query("SELECT inputName,outputName FROM testFileName");
     while ($data = $query->fetch_assoc()) {
        $output=$data['outputName'];
        $input=$data['inputName'];

     }

       while ($data2 = $query2->fetch_assoc()) {
            $testFId = $data2['testFileItemId'];
            $testFName= $data2['testFileItemName'];
            $testInp= $data2['testInputVelue'];
            $testOut = $data2['testOutputVelue'];
           echo '<div class="text-center" style="padding:10px; font-size:18px; display:inline-block;"><div><br>'.$input.':<br>'.$testInp.'<br>'.$output.':<br>'.$testOut.'</div></div>';  
        }

}
function getPseudeCodeFileFilterTask($id){
    $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina') or die($link->connect_errno);
    $query3=$link->query("SELECT task_id,pseudoCodeF FROM tasks Where task_id='$id'");
    while ($data = $query3->fetch_assoc()) {
        $pseudeC = $data['pseudoCodeF'];
        echo '<br><div><a href="download.php?file='.$pseudeC.'" class="pseude-button">Pszeudokód letöltése</a></div>';

    }
}

function getZipFileTask($id){
    $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina') or die($link->connect_errno);
    $query4=$link->query("SELECT solveFile FROM tasks Where task_id='$id'");
    while ($data2 = $query4->fetch_assoc()) {
        $solveF = $data2['solveFile'];
        
        echo '<br><div><a href="download.php?zipFile='.$solveF.'" class="pseude-button" id="makingdifferenttimer" style="display: none;" target="_blank">C/C++/Java kód letöltése</a></div><div id="mdtimer"><b></b><div style="font-size: large;"><b>A letöltéshez várj kérlek <span>900</span> másodpercet</b></div></div><br><br><br>';
    }
}

function getInputElemet($id)
{
    $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina') or die($link->connect_errno);
    $query2=$link->query("SELECT testFileItem.testFileItemId,testFileItem.testFileItemName,testFileItem.testInputVelue,testFileItem.testOutputVelue
    FROM testFileItem join TaskAndTest on testFileItem.testFileItemId=TaskAndTest.testFileItemId 
    join tasks on tasks.task_id =TaskAndTest.task_id where tasks.task_id='$id' LIMIT 1");
    while ($data2 = $query2->fetch_assoc()) {
        $testInp= $data2['testInputVelue'];
        echo $testInp;
  
    }
}
function searchBoxItem(){
    if(isset($_POST['search'])){
        $keyword = $_POST['keyword'];
    }
    $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina');
    
        /* check connection */
        if (mysqli_connect_errno()) {
            printf("Connect failed: %s\n", mysqli_connect_error());
            exit();
        }
    
        //$query = "SELECT taskTitle,task_id FROM tasks ORDER by task_id  LIMIT 5";
        $query=  $link->query("SELECT tasks.taskTitle,tasks.task_id,difficultylevel.LavelName,categories.categorieName FROM categories join tasks on categories.categorieId=tasks.categorieId join difficultylevel on tasks.lavelId =difficultylevel.lavelId where taskTitle LIKE '%$keyword%'");
    
        
            while ($data = $query->fetch_assoc()) {
                $task_id=$data['task_id'];
                $taskTitle=$data['taskTitle'];
                $diffLavel = $data['LavelName'];
                $categorieName = $data['categorieName'];
    
                 // echo '<div class="problem-link">'.$taskTitle."<br>".$diffLavel.'<br>'.$categorieName.'<p class="probLinklem"><a class="solve-link" href="taskItem.php?pageid='.$task_id . '&pagename='. str_replace(' ','-',$taskTitle).'"><br>Megoldás most</a> </p></div>';
                 echo '<div class="problem-link">'.$taskTitle.'<br><a class="diffLevlink"  href="dificultLevel.php?dificultLevel='.$diffLavel.'">'.$diffLavel.'</a><br>'.$categorieName.'<p class="probLinklem"><a class="solve-link" href="taskItem.php?pageid='.$task_id . '&pagename='. str_replace(' ','-',$taskTitle).'"><br>Megoldás most</a> </p></div>';

                }
    
            
        
    
        /* lezaas */
        mysqli_close($link);
}
function getDificultLevelTask($dificultLevel){
    $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina');

    /* check connection */
    if (mysqli_connect_errno()) {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
    }

    //$query = "SELECT taskTitle,task_id FROM tasks ORDER by task_id  LIMIT 5";
    $query=  $link->query("SELECT tasks.taskTitle,tasks.task_id,difficultylevel.LavelName,categories.categorieName FROM categories join tasks on categories.categorieId=tasks.categorieId join difficultylevel on tasks.lavelId =difficultylevel.lavelId where difficultylevel.LavelName='$dificultLevel'");

    
        while ($data = $query->fetch_assoc()) {
            $task_id=$data['task_id'];
            $taskTitle=$data['taskTitle'];
            $diffLavel = $data['LavelName'];
            $categorieName = $data['categorieName'];

              echo '<div class="problem-link">'.$taskTitle.'<br><a class="diffLevlink"  href="dificultLevel.php?dificultLevel='.$diffLavel.'">'.$diffLavel.'</a><br>'.$categorieName.'<p class="probLinklem"><a class="solve-link" href="taskItem.php?pageid='.$task_id . '&pagename='. str_replace(' ','-',$taskTitle).'"><br>Megoldás most</a> </p></div>';
        }

        
    

    /* lezaas */
    mysqli_close($link);
}
/*Tablazatban levo feladatok pontszamai*/
function taskResultShowToTable(){
    $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina') or die($link->connect_errno);
   
    $query2=$link->query("SELECT tasks.taskTitle,taskresult.lang_Name,taskresult.Test1_point,taskresult.Test2_point,taskresult.Test3_point,taskresult.office_point,taskresult.resultDate FROM taskresult JOIN tasks on taskresult.task_id= tasks.task_id");
   
    $query=$link->query("SELECT TaskName,fileextt,Test1PName,Test2PName,Test3PName,OfficePName,TaskResultDate,totalScoreName FROM resulttablenames");
    while ($data = $query->fetch_assoc()) {
      $TaskName=$data['TaskName'];
      $fileExt = $data['fileextt'];
      $Test1Name=$data['Test1PName'];
      $Test2Name=$data['Test2PName'];
      $Test3Name=$data['Test3PName'];
      $OfficeName = $data['OfficePName'];
      $DataName = $data['TaskResultDate'];
      $TotatSName = $data['totalScoreName'];
    }
    $tableName= "<table class='center'><thead><tr>
    <tr><th scope='col'>$TaskName</th>
    <th scope='col'>$fileExt</th>
    <th scope='col'>$Test1Name</th>
    <th scope='col'>$Test2Name</th>
    <th scope='col'>$Test3Name</th>
    <th scope='col'>$OfficeName</th>
    <th scope='col'>$DataName</th>
    <th scope='col'>$TotatSName</th>
    </tr> </thead></table>";
    echo "$tableName";
    while($data2 =$query2->fetch_assoc()){
        $TaskN=$data2['taskTitle'];
        $langExt = $data2['lang_Name'];
        $test1Po= $data2['Test1_point'];
        $test2Po= $data2['Test2_point'];
        $test3Po= $data2['Test3_point'];
        $officePo=$data2['office_point'];
        $taskD = $data2['resultDate'];
        $totalSore= $test1Po+$test2Po+$test3Po+$officePo;

        $TableValue= "<table><tbody><tr>
        <td data-label=$TaskName>$TaskN</td>
        <td data-label=$fileExt>$langExt</td>
        <td data-label=$Test1Name>$test1Po</td>
        <td data-label=$Test2Name>$test2Po</td>
        <td data-label=$Test3Name>$test3Po</td>
        <td data-label=$OfficeName>$officePo</td>
        <td data-label=$DataName> $taskD</td>
        <td data-label=$TotatSName>$totalSore</td>
        </tr></tbody></table>";    
        echo "$TableValue";

    }



}









?>



