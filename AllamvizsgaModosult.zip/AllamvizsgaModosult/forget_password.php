<?php include("navbar.php");?>
<?php include ("login-register-link-bootstap.php")?>
<?php include_once ("controller.php"); ?>


<!doctype html>
<html lang="hu">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/style.css">

</head>
    <title>Elfelejtett jelszó</title>
</head>

<body >
<div id='container'>    
<div  class="was-validated">
    <div class="d-flex justify-content-center align-items-center login-container"  >
       <div id='line'></div> 
         <form class="login-form text-center" method="post" action="forget_password.php" autocomplete="off" >
            <h1 class="mb-5 font-weight-light text-uppercase">Elfelejtetted a jelszót?</h1>
            
            <?php
            
            if ($errors > 0) {
                foreach ($errors as $displayErrors) {
            ?>
                    <div id="alert"><?php echo $displayErrors; ?></div>
            <?php
                }
            }
            ?>
            <div class="form-group">
                <input type="email" id="e-mail" name="e-mail"  class="form-control rounded-pill form-control-lg" placeholder="név@peldául.com" 
                required
                oninvalid="this.setCustomValidity('Email cím')"
                oninput="this.setCustomValidity('')"/>
               <div class="valid-feedback">Email cím forma.</div>
            </div>
            
            <button type="submit" id="forgot_password" name="forgot_password"  class="btn mt-5 rounded-pill btn-lg btn-custom btn-block text-uppercase">Küldés</button>
            <br>
            <p class="mt-3 font-weight-normal">Emlékszel a jelszóra? <a href="login.php"><strong>Jelentkezz be most</strong></a></p>

            <br>
            <p class="mt-3 font-weight-normal">Nincs fiókod? <a href="register.php"><strong>Regisztálj most</strong></a></p>

        </form>
        </div>
         
    </div>
</div>

  
</body>
<script>
  
</script>

</html>