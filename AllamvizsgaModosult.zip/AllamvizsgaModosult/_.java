import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class Main {
//a -> hatvány alapja
//n -> hatvány kitevő
//mivel java-ban nincs unsigned ezert atalakitom minden szamot Math.abs() fuggvennyel pozitivval
static int hatvany1(int a, int n) {
	//trivialis eset a^0=1 -> szabály
    if (Math.abs(n) == 0) {
        return 1;
    }
    else
        return hatvany1(Math.abs(a), Math.abs(n) - 1) * Math.abs(a);
}
static int hatvany2(unsigned a, unsigned n) {
	////trivialis eset a^0=1 -> szabály
    if (Math.abs(n) == 0) {
        return 1;
    }
    else if (Math.abs(n) % 2 == 0) {
        return hatvany2(Math.abs(a), Math.abs(n) / 2) * hatvany2(Math.abs(a), Math.abs(n) / 2);
    }
     else
        return Math.abs(a) * hatvany2(Math.abs(a), Math.abs(n) / 2) * hatvany2(Math.abs(a),Math.abs(n)/ 2);
    
}
 public static void main(String args[]){
   {
        BufferedReader reader = new BufferedReader(
            new InputStreamReader(System.in));
 
        int a = reader.read();
		int n = reader.read();
        
        //int eredmeny = hatvany1(a, n);
        int eredmeny = hatvany2(a, n);
        System.out.println("Eredmeny:" + eredmeny);

    }