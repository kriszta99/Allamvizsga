<?php
function getCompilareCppDefaultInfo(){
    $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina') or die($link->connect_errno);
    $result= $link->query('SELECT langCompilareInfo FROM prog_language where langName="c++"');
    echo $result;

}


?>
<script>
    function cppInfo(){
        var cppDefaultInfo="<?php getCompilareCppDefaultInfo()?>"
        console.log(cppDefaultInfo);    
    }
    
    

</script>