<?php include ("login-register-link-bootstap.php");
session_start();

$pointArray= array();
function validTaskItemValidTestItem(){
    global $pointArray;
    $taskId= $_GET['pageid'];
    $link =mysqli_connect('localhost','krisztina', 'admin', 'krisztina') or die($link->connect_errno);
    $query2=$link->query("SELECT testFileItem.testFileItemName,testFileItem.testInputVelue,testFileItem.testOutputVelue FROM testFileItem join TaskAndTest on testFileItem.testFileItemId=TaskAndTest.testFileItemId join tasks on tasks.task_id =TaskAndTest.task_id where tasks.task_id='$taskId'");
    $testInput=array();
    $testOutput =array();
    $testFileName =array();
    while ($data = $query2->fetch_assoc()) {
        array_push($testInput,$data['testInputVelue']);
        array_push($testOutput,$data['testOutputVelue']);
        array_push($testFileName,$data['testFileItemName']);

    }
    $user_Name = $_SESSION['lastName'];
    $user_id= $_SESSION['userId'];
    $taskName = $_GET['pagename'];
    $output = $_GET['eredmeny'];
    $input = $_GET['bemenet'];
    $pageId= $_GET['pageid'];
    $langU= $_GET['lang'];
    $testT="SELECT resultId,lang_Name FROM taskresult WHERE task_id=$pageId And userId=$user_id And lang_Name='$langU'";
   
    $result = mysqli_query($link,$testT);
    
        //megegyezik
        if($input === $testInput[0] && $output === $testOutput[0]){
            echo '<div id="hideDiv">'.$taskName.'<p>A te bemeneted:'.$input.'<br> A te kimeneted:'.$output.'<br>A helyes bemenet:'.$testInput[0].'<br>A helyes kimenet:'.$testOutput[0].'</p><br>Megegyzeik! Kapsz 3 pontot </div>';
           //$TesztPoint1 = 3;
          
           if(mysqli_num_rows($result) > 0){
            while($row = mysqli_fetch_assoc($result)){
                $resultId=$row['resultId'];
                $resultLang = $row['lang_Name'];
            }
            
            if( $resultLang === $langU ){
            $query = "UPDATE taskresult SET Test1_point=3 WHERE resultId='$resultId'";
            }
            else{
                $query = "INSERT INTO taskresult (Test1_point,Test2_point,Test3_point,office_point,lang_Name,task_id,userId,resultDate)
                VALUES(3,0,0,1,'$langU',$pageId, $user_id, NOW())";
     
            }
           }
           else{
            $query = "INSERT INTO taskresult (Test1_point,Test2_point,Test3_point,office_point,lang_Name,task_id,userId,resultDate)
            VALUES(3,0,0,1,'$langU',$pageId, $user_id, NOW())";

           }
           $result2=mysqli_query($link,$query);


        }
        //bemenet megyezik de a kimenet nem 
        elseif($input === $testInput[0] && $output != $testOutput[0]){
            echo '<div id="hideDiv">'.$taskName.'<p>A te bemeneted:'.$input.'<br> A te kimeneted:'.$output.'<br>A helyes bemenet:'.$testInput[0].'<br>A helyes kimenet:'.$testOutput[0].'</p><br>A kimenet nem egyezik.<br>Kapsz 0 pontot!</div>';
            $TesztPoint1 = 0;
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
                    $resultId=$row['resultId'] ;
                    $resultLang = $row['lang_Name'];

                }
                if( $resultLang === $langU ){
                    $query = "UPDATE taskresult SET Test1_point=0 WHERE resultId='$resultId'";
                }
                else{
                    $query = "INSERT INTO taskresult (Test1_point,Test2_point,Test3_point,office_point,lang_Name,task_id,userId,resultDate)
                    VALUES(0,0,0,1,'$langU',$pageId, $user_id, NOW())";
         
                }    
               }
               else{
                $query = "INSERT INTO taskresult (Test1_point,Test2_point,Test3_point,office_point,lang_Name,task_id,userId,resultDate)
                VALUES(0,0,0,1,'$langU',$pageId, $user_id, NOW())";
    
               }
               $result2=mysqli_query($link,$query);

        }
        //megegyezik
        elseif($input === $testInput[1] && $output === $testOutput[1] ){
            echo '<div id="hideDiv">'.$taskName.'<p>A te bemeneted:'.$input.'<br> A te kimeneted:'.$output.'<br>A helyes bemenet:'.$testInput[1].'<br>A helyes kimenet:'.$testOutput[1].'</p><br>Megegyzeik! Kapsz 3 pontot </div>';
            $TesztPoint1 = 3;
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
                    $resultId=$row['resultId'] ;
                    $resultLang = $row['lang_Name'];

                }
                if($resultLang === $langU){
                $query = "UPDATE taskresult SET Test2_point=3 WHERE resultId=$resultId";
                }
                else{
                    $query = "INSERT INTO taskresult (Test1_point,Test2_point,Test3_point,office_point,lang_Name,task_id,userId,resultDate)
                    VALUES(0,3,0,1,'$langU',$pageId, $user_id, NOW())";
        
                }
               }
               else{
                $query = "INSERT INTO taskresult (Test1_point,Test2_point,Test3_point,office_point,lang_Name,task_id,userId,resultDate)
                VALUES(0,3,0,1,'$langU',$pageId, $user_id, NOW())";
    
               }
               $result2=mysqli_query($link,$query);

        }
        elseif($input === $testInput[1] && $output != $testOutput[1]){
            echo '<div id="hideDiv">'.$taskName.'<p>A te bemeneted:'.$input.'<br> A te kimeneted:'.$output.'<br>A helyes bemenet:'.$testInput[1].'<br>A helyes kimenet:'.$testOutput[1].'</p><br>A kimenet nem egyezik.<br>Kapsz 0 pontot!</div>';
            $TesztPoint1 = 0;
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
                    $resultId=$row['resultId'] ;
                    $resultLang = $row['lang_Name'];

                }
                if($resultLang === $langU){
                $query = "UPDATE taskresult SET Test2_point=0 WHERE resultId=$resultId";
                }
                else{
                    $query = "INSERT INTO taskresult (Test1_point,Test2_point,Test3_point,office_point,lang_Name,task_id,userId,resultDate)
                VALUES(0,0,0,1,'$langU',$pageId, $user_id, NOW())";
     
                }   
               }
               else{
                $query = "INSERT INTO taskresult (Test1_point,Test2_point,Test3_point,office_point,lang_Name,task_id,userId,resultDate)
                VALUES(0,0,0,1,'$langU',$pageId, $user_id, NOW())";
    
    
               }
               $result2=mysqli_query($link,$query);

        }
        elseif($input === $testInput[2] && $output === $testOutput[2] ){
            echo '<div id="hideDiv">'.$taskName.'<p>A te bemeneted:'.$input.'<br> A te kimeneted:'.$output.'<br>A helyes bemenet:'.$testInput[2].'<br>A helyes kimenet:'.$testOutput[2].'</p><br>Megegyzeik! Kapsz 3 pontot </div>';
            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
                    $resultId=$row['resultId'] ;
                    $resultLang = $row['lang_Name'];

                }
                if($resultLang == $langU){
                $query = "UPDATE taskresult SET Test3_point=3 WHERE resultId=$resultId";
                }
                else{
                    $query = "INSERT INTO taskresult (Test1_point,Test2_point,Test3_point,office_point,lang_Name,task_id,userId,resultDate)
                VALUES(0,0,3,1,'$langU',$pageId, $user_id, NOW())";
     
                }
               }
               else{
                $query = "INSERT INTO taskresult (Test1_point,Test2_point,Test3_point,office_point,lang_Name,task_id,userId,resultDate)
                VALUES(0,0,3,1,'$langU',$pageId, $user_id, NOW())";
    
    
               }
               $result2=mysqli_query($link,$query);


        }
        elseif($input === $testInput[1] && $output != $testOutput[2]){
            echo '<div id="hideDiv">'.$taskName.'<p>A te bemeneted:'.$input.'<br> A te kimeneted:'.$output.'<br>A helyes bemenet:'.$testInput[1].'<br>A helyes kimenet:'.$testOutput[1].'</p><br>A kimenet nem egyezik.<br>Kapsz 0 pontot!</div>';

            if(mysqli_num_rows($result) > 0){
                while($row = mysqli_fetch_assoc($result)){
                    $resultId=$row['resultId'] ;
                    $resultLang = $row['lang_Name'];

                }
                if($resultLang == $langU){

                $query = "UPDATE taskresult SET Test3_point=0 WHERE resultId=$resultId";
                }
                else{
                    $query = "INSERT INTO taskresult (Test1_point,Test2_point,Test3_point,office_point,lang_Name,task_id,userId,resultDate)
                    VALUES(0,0,0,1,'$langU',$pageId, $user_id, NOW())";
        
        
                   }
               }
               else{
                $query = "INSERT INTO taskresult (Test1_point,Test2_point,Test3_point,office_point,lang_Name,task_id,userId,resultDate)
                VALUES(0,0,0,1,'$langU',$pageId, $user_id, NOW())";
    
    
               }
               $result2=mysqli_query($link,$query);

        }
        
        else{
            echo '<div id="hideDiv">'.$taskName.'<p>A te bemeneted:'.$input.'<br> A te kimeneted:'.$output.'</p><br>Nem egyezik meg a megadott kimenettel amit a feladat oldalon találsz!</div>';

        }
        
        

    

    
}      


?>
<!DOCTYPE html>

<html lang="hu">
    <head>
        <meta charset="utf-8">

        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>

        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/home.css">


    </head>

    <body class="program-technic" style="background-color:#bc8f8f; margin-top:200px; color:black;">
    <div class="container" >
        <h1 class="text-center" style="clor:white;"><?php  echo  validTaskItemValidTestItem();?></h1>
        <br>

    </div>  
    </div>
    

    
       
    </body>
    <script>

 $(function() {
setTimeout(function() { 
    $("#hideDiv").fadeOut(1500);
 }, 5000)

});



  

</script>
</html>

