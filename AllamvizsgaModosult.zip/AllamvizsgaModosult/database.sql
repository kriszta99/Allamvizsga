/*Felhasznalao tabla*/
 CREATE TABLE users(

     userId int not null AUTO_INCREMENT PRIMARY KEY,
     firstName varchar(100),
     lastName varchar(100),
     UserEmail varchar(200) not null ,
     userPassword varchar(200) not null ,
     registerDate datetime,
     code int(6) not null 


 );
/*Programozasi technikak tabla*/
 CREATE TABLE categories(
     categorieId int not null AUTO_INCREMENT PRIMARY KEY,
     categorieName varchar(100) not null
    

 );
INSERT INTO categories (categorieName) VALUES ('Oszd meg és uralkodj');
INSERT INTO categories (categorieName) VALUES ('Visszalépéses keresés');
INSERT INTO categories (categorieName) VALUES ('Mohó módszer');
INSERT INTO categories (categorieName) VALUES ('Dinamikus programozás');
INSERT INTO categories (categorieName) VALUES ('Elágazás és korlátozás');
/*fooldalom megjeletio*/
 CREATE TABLE homepage(
	homepageId int PRIMARY KEY AUTO_INCREMENT,
    homepageName varchar(100) not null,
    homepageDescript varchar(255) not null
);
/*Kepek*/
 CREATE TABLE pictures(
     pictureId int not null AUTO_INCREMENT PRIMARY KEY,
     homepageId int,
	 pictureName varchar(100),
     pictureNine varchar(150),
     FOREIGN KEY (homepageId) REFERENCES homepage(homepageId)

 ); 

 INSERT INTO homepage(homepageName,homepageDescript) VALUES ('fiok','Szeretnél minél több programozási feladatot megoldani?
De nincs még fiókod?Regisztrálj!');
 INSERT INTO homepage(homepageName,homepageDescript) VALUES ('nyelv_icon','Ezeken a programozási nyelveken oldhatod/írhatod meg a feladatokat:'); 
  INSERT INTO homepage(homepageName,homepageDescript) VALUES ('logo','');
 INSERT INTO homepage (homepageName,homepageDescript) VALUES ('fiok','Kattints ide');
   
INSERT INTO pictures(homepageId,pictureName,pictureNine) VALUES(1,'regisz','icon/regisz.jpg');
INSERT INTO pictures(homepageId,pictureName,pictureNine) VALUES(2,'c++','icon/c++.jpg');
INSERT INTO pictures(homepageId,pictureName,pictureNine) VALUES(2,'c','icon/c.jpg');
INSERT INTO pictures(homepageId,pictureName,pictureNine) VALUES(2,'java','icon/java.jpg');
INSERT INTO pictures(homepageId,pictureName,pictureNine) VALUES(3,'logo','icon/logo.png');
/*programozasi nyelvek tabla megoldashoz es a tesztfilekhez kell */
CREATE TABLE prog_language(
    prog_langId int not null AUTO_INCREMENT PRIMARY KEY,
    langName varchar(25),
    langCompilareInfo varchar(400)

);
INSERT INTO prog_language(langName,langCompilareInfo)VALUES('c++',"\n// 'Ctrl +' megnöveli a betűtípus méretét\n// 'Ctrl -' lecsökkenti a betűtípus méretét\n\n#include <iostream>\nusing namespace std;\n\nint main() {\n\tint num;\n\tcin >> num;\t\t\t//Bemenet beolvasása (STDIN)\n\tcout << \"Kimeneti szám: \" << num << endl;\t// Kimenet kiirása(STDOUT)\n}\n\n\n//Írd ide a saját kódódat!");
INSERT INTO prog_language(langName,langCompilareInfo)VALUES('c',"\n// 'Ctrl +' megnöveli a betűtípus méretét\n// 'Ctrl -' lecsökkenti a betűtípus méretét\n\n#include <stdio.h>\n\nint main() {\n\tint num;\n\tscanf(\"%d\",&num);\t\t\t// Bemenet beolvasása (STDIN)\n\tprintf(\"Kimeneti szám:  %d\",num);\t//Kimenet kiirása(STDOUT)\n\treturn 0;\n}\n\n\n//Írd ide a saját kódódat!");
INSERT INTO prog_language(langName,langCompilareInfo)VALUES('java',"\n// 'Ctrl +' megnöveli a betűtípus méretét\n// 'Ctrl -' lecsökkenti a betűtípus méretét\n\npublic class Main {\n \tpublic static void main(String[] args) { \n\t\tint myNum;\n\t\t myNum = 15;\n\t\t System.out.println(myNum);\n\t}\n}");
INSERT INTO prog_language(langName,langCompilareInfo)VALUES('pseudo',null);
/*Nehezsegi szint*/
 CREATE TABLE difficultylevel(
     lavelId int not null AUTO_INCREMENT PRIMARY KEY,
     LavelName varchar(15)


 );
INSERT INTO difficultylevel(LavelName) VALUES("könnyű");
INSERT INTO difficultylevel(LavelName) VALUES("közép");
INSERT INTO difficultylevel(LavelName) VALUES("nehéz");

 /*Feladatok tabla*/
 CREATE TABLE Tasks(
     task_id int not null AUTO_INCREMENT PRIMARY KEY,
     taskTitle varchar(50) not null,
     taskText varchar(800) not null,
     pseudoCodeF varchar(100),
     solveFile  varchar(100), 
     categorieId int,
     lavelId int,
     FOREIGN KEY (categorieId) REFERENCES categories(categorieId),
     FOREIGN KEY (lavelId) REFERENCES difficultyLevel(lavelId)
);
INSERT INTO tasks(taskTitle,taskText,pseudoCodeF,solveFile,categorieId,lavelId) VALUES ("Hatvány","Írj egy algoritmust az „Oszd meg és urald” programozási technikával az a^n -en kiszámítására ahol az a és az n pozitív szám.","pseudeCode/hatvany_pseudecode.pdf","solveCode/hatvany.zip",1,1);
INSERT INTO tasks(taskTitle,taskText,pseudoCodeF,solveFile,categorieId,lavelId) VALUES ("Maximumkeresés","Adott egy számsorozat, amelyet az a[1..n]
tömbben tároltunk. Határozzuk meg a legnagyobb elem indexét!","pseudeCode/maxkereses_pseudecode.pdf","solveCode/maximum.zip",1,1);
INSERT INTO tasks(taskTitle,taskText,pseudoCodeF,solveFile,categorieId,lavelId) VALUES ("K-dik_legkisebb","Adott egy n elemű számsorozat. Írjunk egy „Oszd meg és uralkodj” algoritmust a k-adik legkisebb elem meghatározására!","pseudeCode/k_legkisebb_pseudecode.pdf","solveCode/k_legkisebb.zip",1,2);

INSERT INTO tasks(taskTitle,taskText,pseudoCodeF,solveFile,categorieId,lavelId) VALUES("Permutáció","Generáljuk az {1, 2, . . ., n} halmaz összes permutációit!","pseudeCode/permutacio.pdf","solveCode/permuatacio.zip",2,1);
INSERT INTO tasks(taskTitle,taskText,pseudoCodeF,solveFile,categorieId,lavelId) VALUES("Csökkenő útkeresés","Adj meg egy 4x4 számokból álló mátrixot a billentyűzetről a megadott bemenetek közül (amit a feladat szövege alatt találsz). Generáld (és írasd ki ahogy a feladat szövege alatt a kimenetben találsz) az összes olyan utat, amelynek mentén a számok szigorúan csökkenő sorrendben követik egymást, az első sor legnagyobb elemétől indul, sorról sorra halad, és az utolsó sorban köt ki. Írasd ki ezek számát is!(lásd a példa kimenetben)","pseudeCode/csokkenoUt.pdf","solveCode/csokkenoUtkereses.zip",2,2);


INSERT INTO tasks(taskTitle,taskText,pseudoCodeF,solveFile,categorieId,lavelId) VALUES("Felvonó","Egy egyszemélyes felvonó előtt n személy áll, akikről ismert, hogy hányadik emeletre szeretnének feljutni (e1, e2,...,en). Milyen sorrendben kellene használják a felvonót, ha azt szeretnék, hogy a várakozási idejük összege minimális legyen? Mennyi lesz ez az összidő, ha tudjuk, hogy a felvonó időegységenként egy emeletmagasságot tesz meg, és a kiszállás és beszállás „szempillantás alatt” történik.","pseudeCode/felvono.pdf","solveCode/felvono.zip",3,1);
INSERT INTO tasks(taskTitle,taskText,pseudoCodeF,solveFile,categorieId,lavelId) VALUES("Huffman","A Huffman-kódolás a következő gondolatmenetet követi: megszámoljuk egy szövegben az egyes karakterek előfordulási számát, majd a gyakoribb karaktereket rövidebb, a ritkábbakat pedig hosszabb bináris kódokkal helyettesítjük. Írjunk egy olyan algoritmust, amely megvalósít egy ilyen kódolás.","pseudeCode/huffman.pdf","solveCode/huffman.zip",3,2);

INSERT INTO tasks(taskTitle,taskText,pseudoCodeF,solveFile,categorieId,lavelId) VALUES("Virágüzlet","Egy virágüzlet kirakatában van 5 váza (1, 2,…, 5 sorrendben) és ezekbe úgy kell elhelyezni az 1, 2, 3, 3 virágokat (ebben a sorrendben; 3<=5), hogy az esztétikai összhatás maximális legyen. Adj meg egy 3x5 számokból álló mátrixot a billentyűzetről a megadott bemenetek közül (amit a feladat szövege alatt találsz) (Az e[1..3,1..5] tömb e[i,j] cellája azt tárolja, hogy az i virág a j vázában milyen esztétikai hatást kelt; az üresen maradt vázák esztétikai hatása nulla)","pseudeCode/viraguzlet.pdf","solveCode/viraguzlet.zip",4,1);
INSERT INTO tasks(taskTitle,taskText,pseudoCodeF,solveFile,categorieId,lavelId) VALUES("Maximális összeg","Adj meg egy 6x2 számokból álló mátrixot a billentyűzetről a megadott bemenetek közül (amit a feladat szövege alatt találsz) s melynek elemei EGÉSZ számok. Egy pók a mátrix első oszlopából indul, egy mozdulattal 1 vagy 2 sort tud haladni (fentről lefele), oszlopot szabadon válthat, és az utolsó sorba kell, hogy eljusson. Mennyi a maximális összeg, amelyet össze tud szedni a pók a mátrixon végig haladva?","pseudeCode/maxosszeg.pdf","solveCode/maxosszeg.zip",4,2);

INSERT INTO tasks(taskTitle,taskText,pseudoCodeF,solveFile,categorieId,lavelId) VALUES("Bináris karakterlánc","Írj egy algoritmust elágazás és korlátozás módszerével, amely generál n hosszúságú bináris karakterláncot, ahol az n egy pozitív szám s ezt olvasd be a billentyűzetről (A kimenete n bináris számjegyből álló számok).","pseudeCode/elagazasKorlatozas.pdf","solveCode/elagazasEskorlatozas.zip",5,2);



/*Teszt fajlok*/
CREATE TABLE testFileName(
    testNameId int not null AUTO_INCREMENT PRIMARY KEY,
    inputName varchar(15),
    outputName varchar(15)
);
INSERT INTO testFileName(inputName,outputName) VALUES ("Bemenet","Kimenet");

CREATE TABLE testFileItem(
    testFileItemId int not null AUTO_INCREMENT PRIMARY KEY,
    testFileItemName varchar(30),
    testInputVelue  varchar(100),
    testOutputVelue varchar(300)


);
CREATE TABLE TaskAndTest(
    taskAndTest_Id int not null AUTO_INCREMENT PRIMARY KEY,
    task_id int,
    testFileItemId int,
    FOREIGN KEY (task_id) REFERENCES Tasks(task_id),
    FOREIGN KEY (testFileItemId) REFERENCES testFileItem(testFileItemId)
);
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Hatvany_teszt1","2 10","1024");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Hatvany_teszt2","30 5","24300000");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Hatvany_teszt3","3 12","531441");

INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Maximum_teszt1","5 38 14 78 5 1","3");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Maximum_teszt2","3 31 2 15","1");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Maximum_teszt3","10 7 81 4 75 2 65 98 71  9 10","7");

INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("K-adik_legkisebb_teszt1","6 7 10 4 3 20 15 3","7");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("K-adik_legkisebb_teszt2","8 10 3 6 9 2 4 15 23 4","6");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("K-adik_legkisebb_teszt3","6 7 10 4 3 20 15 4","10");

INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Permutacio_teszt1","2","12 21 ");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Permutacio_teszt2","3","123 132 213 231 312 321 ");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Permutacio_teszt3","4","1234 1243 1324 1342 1423 1432 2134 2143 2314 2341 2413 2431 3124 3142 3214 3241 3412 3421 4123 4132 4213 4231 4312 4321 ");

INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Csokkeno_utkereses_teszt1","9 8 2 6 5 2 3 4 2 9 1 5 4 0 3 2","Ut: 9 5 2 0 Ut: 9 5 1 0 Ut: 9 2 1 0 Ut: 9 3 2 0 Ut: 9 3 1 0 Ut: 9 4 2 0 Ut: 9 4 1 0 Ossz ut: 7");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Csokkeno_utkereses_teszt2","8 6 7 5 4 9 5 3 2 6 7 4 1 3 0 2","Ut: 8 4 2 1 Ut: 8 4 2 0 Ut: 8 5 2 1 Ut: 8 5 2 0 Ut: 8 5 4 1 Ut: 8 5 4 3 Ut: 8 5 4 0 Ut: 8 5 4 2 Ut: 8 3 2 1 Ut: 8 3 2 0 Ossz ut:10");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Csokkeno_utkereses_teszt3","7 5 1 2 2 3 6 1 1 2 3 0 0 1 2 1","Ut: 7 2 1 0 Ut: 7 3 1 0 Ut: 7 3 2 0 Ut: 7 3 2 1 Ut: 7 3 2 1 Ut: 7 6 1 0 Ut: 7 6 2 0 Ut: 7 6 2 1 Ut: 7 6 2 1 Ut: 7 6 3 0 Ut: 7 6 3 1 Ut: 7 6 3 2 Ut: 7 6 3 1 Ossz ut:13");

INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Felvono_teszt1","5 7 8 4 1 5","Osszesen vart ido:53");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Felvono_teszt2","6 4 1 5 3 6 2","Osszesen vart ido:50");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Felvono_teszt1","7 5 1 6 4 2 3 5","Osszesen vart ido:74");

INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Huffman_teszt1","SAPIENTIA","S:101 A:111 P:100 I:00 E:010 N:011 T:110 I:00 A:111 ");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Huffman_teszt2","KRISZTINA","K:001 R:011 I:111 S:100 Z:110 T:101 I:111 N:010 A:000 ");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Huffman_teszt3","VIRAGOSKERT","V:100 I:1111 R:101 A:1100 G:1110 O:001 S:010 K:000 E:1101 R:101 T:011 ");

INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Virágüzlet_teszt1","7 23 -5 -24 16 5 21 -4 10 23 -21 5 -4 -20 20","0 0 0 0 0 0 0 7 23 23 23 23 0 5 28 28 33 46 0 0 10 24 24 53 ");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Virágüzlet_teszt2","7 13 -5 -14 13 5 11 -4 10 13 -11 3 -3 -20 20","0 0 0 0 0 0 0 7 13 13 13 13 0 5 18 18 23 26 0 0 8 15 15 43 ");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Virágüzlet_teszt3","6 13 -5 -14 15 3 11 -4 12 14 -15 2 -2 -30 30","0 0 0 0 0 0 0 6 13 13 13 15 0 3 17 17 25 27 0 0 5 15 15 55 ");

INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Maxosszeg_teszt1","-1 5 2 9 7 2 0 4 2 1 10 9","Maximalis osszeg, amelyet ossze tud szedni a pok a matrixon: 37");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Maxosszeg_teszt2","-1 5 2 -7 6 2 0 4 -3 1 7 -9","Maximalis osszeg, amelyet ossze tud szedni a pok a matrixon: 25");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("Maxosszeg_teszt3","-6 5 3 -7 -6 8 4 -5 3 -1 -3 12","Maximalis osszeg, amelyet ossze tud szedni a pok a matrixon: 35");

INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("NdarabBinaris_teszt1","2","00 01 10 11 ");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("NdarabBinaris_teszt2","3","000 001 010 011 100 101 110 111 ");
INSERT INTO testFileItem(testFileItemName,testInputVelue,testOutputVelue) VALUES ("NdarabBinaris_teszt3","4","0000 0001 0010 0011 0100 0101 0110 0111 1000 1001 1010 1011 1100 1101 1110 1111 ");


INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES (1,1);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES (1,2);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES (1,3);

INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES (2,4);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES (2,5);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES (2,6);

INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES (3,7);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES (3,8);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES (3,9);

INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES (4,10);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES (4,11);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES (4,12);

INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES (5,13);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES (5,14);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES (5,15);

INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES(6,16);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES(6,17);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES(6,18);

INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES(7,19);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES(7,20);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES(7,21);

INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES(8,22);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES(8,23);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES(8,24);

INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES(9,25);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES(9,26);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES(9,27);

INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES(10,28);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES(10,29);
INSERT INTO TaskAndTest (task_id,testFileItemId) VALUES(10,30);

 CREATE TABLE TaskResult(
     resultId int not null AUTO_INCREMENT PRIMARY KEY,
     Test1_point int not null,
     Test2_point int not null,
     Test3_point int not null,
     office_point int not null,
     lang_Name varchar(10),
     task_id int,
     userId int,
     FOREIGN KEY (task_id) REFERENCES Tasks(task_id),
     FOREIGN KEY (userId) REFERENCES users(userId),
     resultDate datetime
);
CREATE TABLE ResultTableNames(
    Tid int not null AUTO_INCREMENT PRIMARY KEY,
    TaskName varchar(20),
    fileextt varchar(20),
    Test1PName  varchar(20),
    Test2PName  varchar(20),
    Test3PName  varchar(20),
    OfficePName  varchar(20),
    TaskResultDate  varchar(20),
    totalScoreName varchar(20)
);
INSERT INTO ResultTableNames(TaskName,fileextt,Test1PName,Test2PName,Test3PName,OfficePName,TaskResultDate,totalScoreName)
VALUES ('Feladat  címe','Fájlkiterjesztés', 'Tesztfájl1 pontszám','Tesztfájl2 pontszám','Tesztfájl3 pontszám','Hivatalból','Dátum','Összesített pontszám');
