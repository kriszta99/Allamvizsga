<?php
require_once('mysqli_connect.php');
session_start();

// hibak osszes
$errors = [];
//ha ay elfelejtett jelszora klikkel a loginban
if (isset($_POST['forgot_password'])) {
    $email = $_POST['e-mail'];
    $_SESSION['e-mail']=$email;
    $emailCheckQuery = "SELECT userId, firstName, lastName, UserEmail, userPassword, registerDate,code FROM users WHERE UserEmail = '$email'";
    $emailCheckResult = mysqli_query($cone, $emailCheckQuery);
//a lekeres futtatasa
if ($emailCheckResult) {
    // ha az email megegyezik
    if (mysqli_num_rows($emailCheckResult) > 0) {
        $code = rand(999999, 111111);
        $updateQuery = "UPDATE users SET code = $code WHERE UserEmail = '$email'";
        $updateResult = mysqli_query($cone, $updateQuery);
        if ($updateResult) {
            $subject = 'E-mail ellenőrző kód';
            $message = "Az Ön ellenőrző kódja $code";
            $sender = 'From: krisztalukacs99@gmail.com';

            if (mail($email, $subject, $message, $sender)) {
                $message = "Ellenőrző kódot küldtünk az email címére <br> $email";

                $_SESSION['message'] = $message;
                header('location: verifyEmail.php');
            } else {
                $errors['otp_errors'] = 'Nem sikerült a kód küldése!';
            }
        } else {
            $errors['db_errors'] = "Nem sikerült az adatok beszúrása az adatbázisba!";
        }
    }else{
        $errors['invalidEmail'] = "Érvénytelen e-mail cím";
    }
}else {
    $errors['db_error'] = "Nem sikerült az e-mail cím az adatbázisból történő ellenőrzése!";
    }
}
if(isset($_POST['verifyEmail'])){
    $_SESSION['message'] = "";
    $OTPverify = mysqli_real_escape_string($cone, $_POST['OTPverify']);
    $verifyQuery = "SELECT * FROM users WHERE code = $OTPverify";
    $runVerifyQuery = mysqli_query($cone, $verifyQuery);
    if($runVerifyQuery){
        if(mysqli_num_rows($runVerifyQuery) > 0){
            $newQuery = "UPDATE users SET code = 0";
            $run = mysqli_query($cone,$newQuery);
            header("location: resetPassword.php");
        }else{
            $errors['verification_error'] = "Érvénytelen ellenörző kód";
        }
    }else{
        $errors['db_error'] = "Nem sikerült az ellenőrző kód ellenőrzése az adatbázisból!";
    }
}
/// If Reset Password Button Will Clicked
if(isset($_POST['resetPassword'])){
    $_SESSION['message'] = "";
    $email = $_SESSION['e-mail'];
	$newPassword = ($_POST['newPassword']);
	$confirmPassword = ($_POST['confirmPassword']);


    $salt="codeflix";
    $passwordN = sha1($newPassword.$salt);
    
    if (strlen($_POST['newPassword']) < 8) {
        $errors['password_error'] = 'Használjon 8 vagy több karaktert betűk, számok és szimbólumok keverékével';
    } else {
        // if password not matched so
        if($newPassword === $confirmPassword){
               // Update Password
               $updatePsdQuery = "UPDATE users SET userPassword = '$passwordN' WHERE UserEmail = '$email'";
               $runUpdatePsdQuery = mysqli_query($cone, $updatePsdQuery);
               if($runUpdatePsdQuery){
					$_SESSION['message'] = "A jelszó megváltozott";
					header('location: login.php');             

               }else{
                    $errors['passwordError'] = "A jelszó nem változott meg";
            }
        }
        else{
            $errors['passwordError'] = "A jelszó nem egyezik";

        }
		
    }
}  

?>

