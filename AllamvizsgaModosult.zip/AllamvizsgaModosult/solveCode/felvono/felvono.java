import java.util.*;
class  Main
{
   public static void felvono(int[] e,int n){
        int ossz_var_ido,akt_szemely_var_ido,i;
       Arrays.sort(e);///rendezuk az emberek szamsorat noovekvo sorerndbe
        ossz_var_ido = 0;///az ooszesn vart ido kezdetben 0-a
        akt_szemely_var_ido = 0;///az aktualis szemeny vart ideje kezdetben 0-a
        ///az i=2 azert mert a legalso szinre nem kell felvono vagyis az 1 szinre mert az a foldszint

        for(i=2;i<=n;i++ ){
            ///a szemely varkozasai ideje emberek1+emberek2+...+emberek(i-1)
            akt_szemely_var_ido = akt_szemely_var_ido + e[i-1];
            ///az osszes vart idot ugy kapjuk meg h hozzaadjuk a szemely vart idot ugy viselkedik olyan mint egy szamlalo

            ossz_var_ido = ossz_var_ido + akt_szemely_var_ido;
        }
        System.out.println("Osszesen vart ido:"+ossz_var_ido);
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int[] emberek;
        int n = in.nextInt();
        ///helyfogalas az emberek tombjenek
        emberek= new int[n];

        ///feltoltes az emberek tomjenek
        for( int i=0;i<n;i++){
            emberek[i]=in.nextInt();
        }

        felvono(emberek,n);




    }


}