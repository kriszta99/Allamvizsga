#include <stdio.h>
#include <stdlib.h>

void mergesort(int* a, int n);
void felvono(int *e,int n);
void osszefesules(int* a, int n);

int main()
{   int*emberek,n,i;

    scanf("%i",&n);
    ///helyfogalas az emberek tombjenek
    emberek=(int*)calloc(n,sizeof(int));
    if(emberek==NULL){
        printf("Nincs helyfoglasa!");
    }
    ///feltoltes az emberek tomjenek
    for(i=0;i<n;i++){
        scanf("%i",&emberek[i]);
    }
   
    felvono(emberek,n);

   free(emberek);

    return 0;
}

void felvono(int *e,int n){
    int ossz_var_ido,akt_szemely_var_ido,i;
    mergesort(e,n);///rendezuk az emberek szamsorat noovekvo sorerndbe
    ossz_var_ido = 0;///az ooszesn vart ido kezdetben 0-a
    akt_szemely_var_ido = 0;///az aktualis szemeny vart ideje kezdetben 0-a
    ///az i=2 azert mert a legalso szinre nem kell felvono vagyis az 1 szinre mert az a foldszint

    for(i=2;i<=n;i++ ){
        ///a szemely varkozasai ideje emberek1+emberek2+...+emberek(i-1)
        akt_szemely_var_ido = akt_szemely_var_ido + e[i-1];
    ///az osszes vart idot ugy kapjuk meg h hozzaadjuk a szemely vart idot ugy viselkedik olyan mint egy szamlalo

        ossz_var_ido = ossz_var_ido + akt_szemely_var_ido;
    }
    printf("\nOsszesen vart ido:%i",ossz_var_ido);
}

void mergesort(int* a, int n)
{
	if (n > 1)
	{
		mergesort(a, n / 2);
		mergesort(a + n / 2, n - n / 2);
		osszefesules(a, n);
	}
}
void osszefesules(int* a, int n)
{
	///Az a[0..n-1] és b[0..m-1] számsorokat összefésüli a c[0..n+m-1] tömbbe
	int i, j, k;
	int* b = a + n / 2;
	int* c = (int*)malloc(n * sizeof(int));
	i = j = k = 0;
	while (i < n/2 && j < n-n/2) {
		if (a[i] < b[j])
		{ c[k++] = a[i++]; }
		else { c[k++] = b[j++]; }
	}
	while (j < n-n/2) {
		c[k++] = b[j++];
	}
	while (i < n/2) {
		c[k++] = a[i++];
	}
	for (i = 0; i < n; ++i)
	{
		a[i] = c[i];
	}
	free(c);
}





