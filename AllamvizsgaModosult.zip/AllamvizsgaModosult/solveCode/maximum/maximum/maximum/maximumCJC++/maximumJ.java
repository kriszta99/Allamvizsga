import java.util.*;
class  Main
{
    static int maxindex(int[] a,int i,int j){
        if(i == j){
            return i;
        }
        else{
            int m1 = maxindex(a,i,(i+j)/2);
            int m2 = maxindex(a,(i+j)/2+1,j);
            if(a[m1] > a[m2]){
                return m1;
            }
            else{
                return m2;
            }
        }
    }
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int[] a = new int[25]; // ennyi a memoriaja

        for (int i = 1; i <= n; i++) {
            // read input
            a[i] = scan.nextInt();

        }

            System.out.println(maxindex(a, 1, n));

    }
}