#include <iostream>
using namespace std;
int maxindex(int a[],int i,int j){
    if(i == j){
        return i;
    }
    else{
        int m1 = maxindex(a,i,(i+j)/2);
        int m2 = maxindex(a,(i+j)/2+1,j);
        if(a[m1] > a[m2]){
            return m1;
        }
        else{
            return m2;
        }
    }
}
int main() {
	int n;
	cin>>n;
	int a[n];
	for (int i = 1; i <= n; ++i) {
		cin >> a[i];
	}

	
	
    int eredmeny = maxindex(a,1,n);
    cout<<eredmeny<<endl;
    
    return 0;
}