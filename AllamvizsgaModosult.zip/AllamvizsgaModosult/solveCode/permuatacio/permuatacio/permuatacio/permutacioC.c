#include <stdio.h>
#include <stdbool.h>

void permutacio(int* x, int n, int k);
bool igeretes(int* x, int k);
bool megoldas(int p, int k);
void kiir(int* x, int k);
int main(){
	int x[100],n;
	scanf("%i", &n);
	permutacio(x, n, 0);
    printf("\n");
	return 0;

}
void permutacio(int* x, int n, int k) {
    if (megoldas(n, k)) {
        kiir(x, k);
    }
    else {
        for (x[k + 1] = 1; x[k + 1] <= n; ++x[k + 1]) {
            if (igeretes(x, k + 1)) {
                permutacio(x, n, k + 1);
            }
        }
    }
}
bool igeretes(int* x, int k) {
    //tulajdonsga h legyen kulombozo az azelotti szinitol
    for (int i = 1; i <= k - 1; ++i) {
        if (x[i] == x[k]) {
            return false;
            //ha ugyan olyan akkor hamis
        }
    }
    //ha igaz akkor nincs ket egyforma szam
    return true;
}
bool megoldas(int n, int k) {
    if (k == n) {
        return true;
    }
    else {
        return false;
    }
}
void kiir(int* x, int k) {
    for (int i = 1; i <= k; ++i) {
        printf("%i", x[i]);
    }
    printf(" ");
}