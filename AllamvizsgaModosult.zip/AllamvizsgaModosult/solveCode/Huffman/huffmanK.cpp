// Online C++ compiler to run C++ program online
#include <iostream>
#include<cstdlib>
#include <cstring>
#include <climits>
using namespace std;





typedef struct {
    int apa, frecvencia;
    char karakter;
    int balfiu, jobbfiu;
}ELEM;
void epito(ELEM*, int, char*);
int minindex(ELEM*, int);
int main()
{
   
    char word[25];
    scanf("%s", word);
    
    int i;
    char** kodok;
    char karakter[25];
    int szamlalo = 0;
    int balfiu, jobbfiu;
    int stat[256] = { 0 }, n = 0;
        char c;
   for(int e=0;e<strlen(word);e++){
       c = word[e];
        ++stat[c];
        
        szamlalo++;
        karakter[szamlalo] = c;
        if (stat[c] == 1) { ++n; }
    }
    //stat[255] = 1; n++;
    
    kodok = (char**)calloc(256, sizeof(char*));
    for (int i = 0; i < 256; ++i) {
        if (stat[i]) {
            kodok[i] = (char*)calloc(n, sizeof(char));
        }
    }
    ELEM* huffman;
    int j = 0;
    huffman = (ELEM*)calloc(2 * n - 1, sizeof(ELEM));
    if (huffman == NULL) {
       cout<<"nincs helyfoglalas";
        return 0;
    }

    
    for (int i = 0; i < 256; i++) {
        if (stat[i]) {

            huffman[j].karakter = i;
            huffman[j].frecvencia = stat[i];
            ++j;
        }
    }
    

    
    int m = n;
    for (int k = 0; k < n - 1; k++) {
        balfiu = minindex(huffman, m);
         
        huffman[balfiu].apa = (-1) * m;
        huffman[m].frecvencia += huffman[balfiu].frecvencia;
        huffman[m].balfiu=balfiu;
        jobbfiu = minindex(huffman, m);
        huffman[jobbfiu].apa = m;
        huffman[m].frecvencia += huffman[jobbfiu].frecvencia;
        huffman[m].jobbfiu = jobbfiu;
        ++m;

    }

  
    int r;
    for ( r = 0; r < n; r++) {
        epito(huffman, r,kodok[huffman[r].karakter]);
    }
    for (int e = 0; e <= szamlalo; e++) {
        for (int i = 0; i < 256; i++) {
            if (kodok[i]) {

                if (karakter[e] == i) {
                    cout<<karakter[e]<<":"<< kodok[i]<<" ";

                }
            }


        }

    }

    return 0;
}
int minindex(ELEM* huffman, int m) {
    int minpoz,mini= INT_MAX;
    for (int i = 0; i < m; ++i) {
        if (huffman[i].apa) {
            continue;
        }
        if (huffman[i].frecvencia < mini) {
            mini = huffman[i].frecvencia;
            minpoz = i;
        }
    }
    return minpoz;
}
void epito(ELEM* huffman, int id,  char* kod) {
    
        if (huffman[id].apa) {
            
            if (huffman[id].apa > 0) {
                epito(huffman,huffman[id].apa, kod);
                strcat(kod, "1");
            }
            else {
                epito(huffman,-huffman[id].apa, kod);
                strcat(kod, "0");
            }


        }
    
    
}
