// Java Program to generate
// Binary Strings using Branch and Bound

import java.io.*;
import java.util.*;

// Creating a Node class
class Node {

	int soln[];
	int level;
	ArrayList<Node> child;
	Node parent;

	Node(Node parent, int level, int N)
	{
		this.parent = parent;
		this.level = level;
		this.soln = new int[N];
	}
}

class Main {

	static int N;

	// Queue that maintains the list of live Nodes
	public static Queue<Node> Q;

	// Utility function to generate binary strings of length n
	public static void generate(Node n)
	{
		// If list is full print combination
		if (n.level == N) {
			for (int i = 0; i <= N - 1; i++) {
				System.out.print(n.soln[i]);
			}
			System.out.print(" ");
		}
		else {

			// Create a new vector for new combination
			n.child = new ArrayList<Node>();

			int l = n.level;

			// iterate while length is not equal to n
			for (int i = 0; i <= 1; i++) {
				Node x = new Node(n, l + 1, N);
				for (int k = 0; k < l; k++) {
					x.soln[k] = n.soln[k];
				}
				x.soln[l] = i;
				n.child.add(x);
				Q.add(x);
			}
		}
	}

	// Driver code
	public static void main(String args[])
	{
		// Initiate Generation
		// Create a root Node
		N = 3;
		Node root = new Node(null, 0, N);

		// Instantiate the Queue
		Q = new LinkedList<Node>();
		Q.add(root);

		while (Q.size() != 0) {
			Node E = Q.poll();
			generate(E);
		}
	}
}
