// Binary Strings using Branch and Bound
#include <bits/stdc++.h>
using namespace std;

class Node
{
public:
	int *soln;
	int level;
	vector<Node *> child;
	Node *parent;

	Node(Node *parent, int level, int N)
	{
		this->parent = parent;
		this->level = level;
		this->soln = new int[N];
	}
};

// Segédfunkció n hosszúságú bináris karakterláncok előállításához
void generate(Node *n, int &N, queue<Node *> &Q)
{
	
	if (n->level == N)
	{
		for (int i = 0; i < N; i++)
			cout << n->soln[i];
		cout <<" ";
	}
	else
	{
		int l = n->level;

		
		for (int i = 0; i <= 1; i++)
		{
			Node *x = new Node(n, l + 1, N);
			for (int k = 0; k < l; k++)
				x->soln[k] = n->soln[k];
			x->soln[l] = i;
			n->child.push_back(x);
			Q.push(x);
		}
	}
}

int main()
{
	
	int N;
	cin>>N;
	Node *root;
	root = new Node(NULL, 0, N);

	queue<Node *> Q;
	
	Q.push(root);

	while (!Q.empty())
	{
		Node *E = Q.front();
		Q.pop();
		generate(E, N, Q);
	}

	return 0;
}

