#include <iostream>
#include <cstdlib>

using namespace std;
bool maxi(int a, int b);
void tomb_kiirasa(int* a, int n);
int counter = 0;
int csokkenoUtkereses(int** a, int* x, int n, int m, int k,int maximum);
int main() {
	int**a, i, j=0;
	int n=4,m=4;
   
	//matrix helyfoglalasa
	a = (int**)calloc(n, sizeof(int*));
	if (a == NULL) {
		cout<<"Nincs helyfogalas!";

	}
	for (i = 0; i < n; i++) {
		a[i] = (int*)calloc(m, sizeof(int));
		if (a[i] == NULL) {
		cout<<"Nincs helyfogalas!";

		}
	}
	//matrix feltoltese billentyurol
   for(i=0; i<n; i++) {
      for(j=0;j<m;j++) {
         cin>>a[i][j];
      }
   }
	//kell egy x tomb amibe epitjuk fel a beakcktrackinget
	int* x, maximum;
	x = (int*)calloc(n*m, sizeof(int));
	if (x == NULL) {
		cout<<"Nincs helyfogalas!";
	}
	//keressuk meg a matrixban az elso soraban a legnagyobb elemet mert ettol fogunk indulni
	for (int i = 0; i < n; i++) {
		if (maxi(a[0][0], a[0][i+1])) {
			 maximum= a[0][0];
		}
		else {
			 maximum = a[0][i+1];
		}
	}
	
	int t=csokkenoUtkereses(a, x, n, m, 1,maximum);
	cout<<"Ossz ut: "<<t;
	
	
	//a matrix felszabaditasa

	for (i = 0; i < n; i++) {
		free(a[i]);
	}
	free(a);

	return 0;
}


bool maxi(int a, int b) {
	return a > b ? true : false;
}

void tomb_kiirasa(int* a, int k) {
	cout<<"Ut: ";
	for (int i = 0; i < k; i++) {
	cout<<a[i]<<" ";
		
	}
	
}
int   csokkenoUtkereses(int** a, int* x, int n, int m, int k, int maximum) {

	if (k == n) { //akkor kell kiirni ha negy elemet osszekeresett s ez csak akkor lesz jo ha a ka egyenlo n el mivel az n az 4

		tomb_kiirasa(x, n);
		counter++;
	}

	else {
		for (int j = 0; j < m; j++) {
			x[k] = a[k][j];
			x[0] = maximum;
			if (x[0] > x[k] && x[k - 1] > x[k]) {


				csokkenoUtkereses(a, x, n, m, k + 1, maximum);
			}


		}

	}
	return counter;
}




