import java.util.*;
class  Main
{
    private static int counter=0;


    public static boolean maxi(int a, int b) {
        return a > b;
    }

    public static void tomb_kiirasa(int[] a, int k) {
        System.out.print("Ut: ");

        for (int i = 0; i < k; i++) {

            System.out.print(a[i]+" ");

        }

    }
    public static int csokkenoUtkereses(int[][] a, int[] x, int n, int m, int k, int maximum) {

        if (k == n) { //akkor kell kiirni ha negy elemet osszekeresett s ez csak akkor lesz jo ha a ka egyenlo n el mivel az n az 4

            tomb_kiirasa(x, n);
            counter++;
        }

        else {
            for (int j = 0; j < m; j++) {
                x[k] = a[k][j];
                x[0] = maximum;
                if (x[0] > x[k] && x[k - 1] > x[k]) {


                    csokkenoUtkereses(a, x, n, m, k + 1, maximum);
                }


            }

        }
        return counter;
    }
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int i, j=0;
        int n=4,m=4;
        int [][] a = new int[n+1][m+1];
        //matrix feltoltese billentyurol
        for(i=0; i<n; i++) {
            for(j=0;j<m;j++) {
                a[i][j]=in.nextInt();
            }
        }
        //kell egy x tomb amibe epitjuk fel a beakcktrackinget
        int[] x = new int[n*m];
        int  maximum = 0;

        //keressuk meg a matrixban az elso soraban a legnagyobb elemet mert ettol fogunk indulni
        for (i = 0; i < n; i++) {
            if (maxi(a[0][0], a[0][i+1])) {
                maximum= a[0][0];
            }
            else {
                maximum = a[0][i+1];
            }
        }

        int t=csokkenoUtkereses(a, x, n, m, 1,maximum);
        System.out.print("Ossz ut: "+t);


    }


}