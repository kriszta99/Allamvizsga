// Online C++ compiler to run C++ program online
#include <iostream>
#include<cstdlib>
using namespace std;
int max(int, int);

int main()
{
   
    int** c, ** e, n=3, m=5;
   
    e = (int**)calloc(n, sizeof(int*));
    if (e == NULL) {
        cout<<"Nincs helyfoglalas!";
        return 0;
    }

    for (int i = 1; i <= n; i++) {
        e[i] = (int*)calloc(m, sizeof(int));
        if (e[i] == NULL) {
        cout<<"Nincs helyfoglalas!";
            return 0;
        }
    }
    //billentyurol feltoltese
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            cin>>e[i][j];
        }

    }c = (int**)calloc(n, sizeof(int*));
    if (c == NULL) {
        cout<<"Nincs helyfoglalas!";
        return 0;
    }

    for (int i = 0; i <= n; i++) {
        c[i] = (int*)calloc(m + 1, sizeof(int));
        if (c[i] == NULL) {
        cout<<"Nincs helyfoglalas!";
            return 0;
        }
    }
    
    //Trivialis eset 1:
    for (int j = 0; j <= m - n; j++) {
        c[0][j] = 0;
    }
    //Trivialis eset 2:
    for (int i = 1; i <= n; i++) {
        c[i][i] = c[i - 1][i - 1] + e[i][i];
        //az i edik vaza iedik vazaba kerul
    }
    //A parol apara
    for (int i = 1; i <= n; i++) {
        for (int j = i + 1; j <= m - n + i; j++) {
            if (c[i - 1][j - 1] + e[i][j] > c[i][j - 1]) {
                c[i][j] = c[i - 1][i - 1] + e[i][j];
            }
            else {
                c[i][j] = c[i][i - 1];
            }
        }
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            c[i][j] = max(c[i - 1][j - 1] + e[i][j], c[i][j - 1] + 0);
        }
    }

    for (int i = 0; i <= n; i++) {
        for (int j = 0; j <= m; j++) {
            cout<<c[i][j]<<" ";
        }

    }



    return 0;



}
int max(int a, int b) {
    if (a > b) {
        return a;
    }
    else return b;
}