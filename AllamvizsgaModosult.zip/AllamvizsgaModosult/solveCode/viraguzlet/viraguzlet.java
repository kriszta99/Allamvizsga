class  Main
{
   public static  int max(int a, int b) {
        if (a > b) {
            return a;
        }
        else return b;
    }

    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        int n=3,m=5;
        int [][] e = new int[n][m];
        int [][] c = new int[n][m];

        //matrix feltoltese billentyurol
        for(int i=1; i<=n; i++) {
            for(int j=1;j<=m;j++) {
                e[i][j]=in.nextInt();
            }
        }
        //Trivialis eset 1:
        for (int j = 0; j <= m - n; j++) {
            c[0][j] = 0;
        }
        //Trivialis eset 2:
        for (int i = 1; i <= n; i++) {
            c[i][i] = c[i - 1][i - 1] + e[i][i];
            //az i edik vaza iedik vazaba kerul
        }
        //A parol apara
        for (int i = 1; i <= n; i++) {
            for (int j = i + 1; j <= m - n + i; j++) {
                if (c[i - 1][j - 1] + e[i][j] > c[i][j - 1]) {
                    c[i][j] = c[i - 1][i - 1] + e[i][j];
                }
                else {
                    c[i][j] = c[i][i - 1];
                }
            }
        }
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                c[i][j] = max(c[i - 1][j - 1] + e[i][j], c[i][j - 1] + 0);
            }
        }

        for (int i = 0; i <= n; i++) {
            for (int j = 0; j <= m; j++) {
                System.out.print(c[i][j]+" ");
            }

        }







    }


}