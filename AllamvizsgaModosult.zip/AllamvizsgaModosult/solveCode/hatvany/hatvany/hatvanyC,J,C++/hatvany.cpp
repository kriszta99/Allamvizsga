﻿#include <iostream>
using namespace std;
//a -> hatvány alapja
//n -> hatvány kitevő
int hatvany1(unsigned a, unsigned n) {
	//trivialis eset a^0=1 -> szabály
    if (n == 0) {
        return 1;
    }
    else
        return hatvany1(a, n - 1) * a;
}
int hatvany2(unsigned a, unsigned n) {
	////trivialis eset a^0=1 -> szabály
    if (n == 0) {
        return 1;
    }
    else if (n % 2 == 0) {
        return hatvany2(a, n / 2) * hatvany2(a, n / 2);
    }
     else
        return a * hatvany2(a, n / 2) * hatvany2(a,n/ 2);
    
}
int main()
{
    unsigned a;
    //azert unsigned a hatvanykitevo mert nem lehet negativ szam
    unsigned n;
    cin >> a;
    cin >> n;
    //int eredmeny = hatvany1(a, n);
    int eredmeny = hatvany2(a, n);
    cout << eredmeny;

    return 0;
}


