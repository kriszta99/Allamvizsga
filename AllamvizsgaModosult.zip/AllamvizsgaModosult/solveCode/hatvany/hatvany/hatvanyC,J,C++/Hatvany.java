import java.util.*;
class  Main
{
    static int hatvany1(int a, int n) {
        if (n == 0) {
            return 1;
        }
        else
            return hatvany1(a, n - 1) * a;
    }
    static int hatvany2(int a, int n) {
        if (n == 0) {
            return 1;
        }
        else if (n % 2 == 0) {
            return hatvany2(a, n / 2) * hatvany2(a, n / 2);
        }
        else
            return a * hatvany2(a, n / 2) * hatvany2(a,n/ 2);

    }

    public static void main(String[] args)
    {
        Scanner sc= new Scanner(System.in);    //System.in is a standard input stream  
        int a= sc.nextInt();
        int n= sc.nextInt();


        //int eredmeny = hatvany1(a, n);
        int eredmeny = hatvany2(a, n);
        System.out.println(eredmeny);

    }


}