#include <iostream>
using namespace std;
int szetvalogat(int a[], int bal, int jobb) 
{ 
   int p=bal;
   int q=jobb;
   int w=a[bal];
   while(p < q){
       if(a[p] <= a[q]){
           if( w == a[p]){
               q=q-1;
           }
           else{
               p=p+1;
           }
       }
       else{
           int v=a[p];
           a[p]=a[q];
           a[q]=v;
           
       }
   }
   return p;
   
}
int kadiklegkisebb(int a[], int bal , int jobb, int k)
{
    if (bal == jobb)
         return a[bal];
    int index = szetvalogat(a, bal, jobb);
    int szamalo = index - bal + 1;
    if ( szamalo == k )
         return a[index];
    else if ( szamalo > k )      
         return kadiklegkisebb(a, bal, index-1, k);
    else                 
         return kadiklegkisebb(a, index+1, jobb, k-(index - bal + 1)) ;  
}

int main() {
   int n;
	cin>>n;
	int a[n];
	for (int i = 1; i <= n; ++i) {
		cin >> a[i];
	}
	  int k;
	  cin>>k;
	  int eredmeny = kadiklegkisebb(a,1,n,k);
	  cout<<eredmeny;
	  
    return 0;
}