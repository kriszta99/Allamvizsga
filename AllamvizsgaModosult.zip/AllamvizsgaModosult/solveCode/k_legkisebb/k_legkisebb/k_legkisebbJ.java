import java.util.*;
class  Main
{
    static int szetvalogat(int[] a, int bal, int jobb)
    {
        int p=bal;
        int q=jobb;
        int w=a[bal];
        while(p < q){
            if(a[p] <= a[q]){
                if( w == a[p]){
                    q=q-1;
                }
                else{
                    p=p+1;
                }
            }
            else{
                int v=a[p];
                a[p]=a[q];
                a[q]=v;

            }
        }
        return p;

    }
    static int kadiklegkisebb(int[] a, int bal , int jobb, int k)
    {
        if (bal == jobb)
            return a[bal];
        int index = szetvalogat(a, bal, jobb);
        int szamalo = index - bal + 1;
        if ( szamalo == k )
            return a[index];
        else if ( szamalo > k )
            return kadiklegkisebb(a, bal, index-1, k);
        else
            return kadiklegkisebb(a, index+1, jobb, k-(index - bal + 1)) ;
    }
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int n = scan.nextInt();
        int[] a = new int[n+1]; // ennyi a memoriaja

        for (int i = 1; i <= n; i++) {
            // read input
            a[i] = scan.nextInt();

        }
        int k = scan.nextInt();
        System.out.println(kadiklegkisebb(a, 1, n,k));

    }
}