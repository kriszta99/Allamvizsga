import java.util.*;
class  Main
{
    public static int maximum(int a, int b) {
        if (a > b) {
            return a;
        }
        else {
            return b;
        }

    }
   public static int maxi(int a, int b, int c, int d) {
        int maximum = a;
        if (maximum < b) {
            maximum = b;

        }
        if (maximum < c) {
            maximum = c;

        }
        if (maximum < d) {
            maximum = d;

        }
        return maximum;

    }
    public static void dinamikus(int[][] a, int[][] c, int n) {
        int j = 0;
        for(int i=1;i<n;i++){
            if (i == 1) {
                c[i][j] = maximum(c[i - 1][j], c[i - 1][j + 1]) + a[i][j];
                //printf("%i", c[i][j]);
                c[i][j+1]=maximum(c[i - 1][j], c[i - 1][j + 1]) + a[i][j+1];
                //printf("%i", c[i][j+1]);

            }

            else {
                //printf("%i ", a[i-2][j]);

                c[i][j] = maxi(c[i-1][j], c[i-1][j + 1], c[i - 2][j], c[i - 2][j + 1]) + a[i][j];
                c[i][j+1] = maxi(c[i-1][j], c[i-1][j + 1], c[i - 2][j], c[i - 2][j + 1]) + a[i][j+1];
            }






        }

    }




    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        int n=6;
        int [][] matrix = new int[n][2];
        int [][] matrix2 = new int[n][2];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < 2; j++) {
                matrix[i][j]=in.nextInt();
            }
        }
        //a matrix2 matrix elso sora ugyan az mint a matrix soranak
        for (int j = 0; j < 2; j++) {
            matrix2[0][j] = matrix[0][j];
        }
        dinamikus(matrix, matrix2, n);
        int maxi = maximum(matrix2[n - 1][0], matrix2[n - 1][1]);
        System.out.print("Maximalis osszeg, amelyet ossze tud szedni a pok a matrixon: "+maxi);


    }


}