<?php 
include("navbar2.php");
?>
<!DOCTYPE html>

<html lang="hu">
    <head>
        <meta charset="utf-8">

        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>

        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/taskItemShow.css">
        <link rel="stylesheet" href="css/taskTableShow.css">

        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <title>Task</title>


    </head>
    <body>
   
    <div class="overflow-scroll">

    <div class="column text-center" id="resultTable" >
        <div class="">
        <?php echo taskResultShowToTable();?>
        &nbsp; &nbsp;

        </div>
    </div>
    </div>
    </body>
    <style>


    </style>
</html>