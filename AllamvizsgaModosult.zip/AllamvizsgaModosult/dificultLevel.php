<?php
include("navbar2.php");
include ("login-register-link-bootstap.php");
?>
<!DOCTYPE html>

<html lang="hu">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Nehézségi szint</title>
        <link rel="stylesheet" href="css/home.css">


    </head>

    <body class="program-technic">
    <div class="container">
        <h1 class="text-center prog-tech-title"></h1>
        <br>

    </div>  
    </div>
    <div class="scollbar">

    <div class="programBody">
               
                <?php echo getDificultLevelTask($_GET['dificultLevel']);?>

            
            

    </div> 
    </div> 

    
       
    </body>

</html>
