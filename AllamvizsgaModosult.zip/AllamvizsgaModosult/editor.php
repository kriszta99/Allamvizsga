<!DOCTYPE html>
<html lang="hu" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>C/C++/JAVA</title>
    <meta name="author" content="SidPro">
    <meta name="description" content="Online C,C++,JAVA compiler">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css" integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.12/ace.js" integrity="sha512-GZ1RIgZaSc8rnco/8CXfRdCpDxRCphenIiZ2ztLy3XQfCbQUSCuk8IudvNHxkRA3oUg6q0qejgN/qqyG1duv5Q==" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.12/ext-themelist.min.js" integrity="sha512-5CwAfXQtNsk5OzybMAJ3U14TStTq6jUHJoWxu58KOyioLXO3fX6FPUKaYp/2iF6yZMkv38fvh3nH+Vq94R2BUg==" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ace/1.4.12/ext-language_tools.min.js"></script>
    <link rel="stylesheet" href="css/compiler.css">
  
  </head>

  <br><br><br>
  <body>
  <body onload="ready()">
  
    <div class="container">

    
      <button title="Fájl feltöltés" onclick="upload()" class="download-btn"><i class="fas fa-file-upload"></i></button>
      <button title="Kód letöltés" onclick="download()" class="download-btn"><i class="fa fa-download"></i></button>

    <div class="semicontainer">
          <div class="labeltheme">
           <!-- <label for="modes">Programozási nyelv:</label> Nem kell ide a risize miadt-->
              <select id="modes" size="1" onchange="changeMode()" style="background:#e8e8e8 url('chevron-down-solid.svg') no-repeat 90% 50%;-webkit-appearance: none;">
                <option value="ace/mode/java">java</option>
                <option value="ace/mode/c_cpp" selected>cpp</option>
                <option value="ace/mode/c_cpp">c</option>
              </select>
          </div>
          <div class="labeltheme">
            <!--<label for="theme">Téma:</label> Nem kell ide a risize miadt-->

            <select id="theme" size="1" onchange="changeTheme()" style="background:#e8e8e8 url('adjust-solid.svg') no-repeat 90% 50%;-webkit-appearance: none;">
              <option value="ace/theme/cobalt" selected>Cobalt</option>
              <option value="ace/theme/dracula">Dracula</option>
              <option value="ace/theme/idle_fingers">Idle Fingers</option>
              <option value="ace/theme/merbivore_soft">Merbivore Soft</option>
              <option value="ace/theme/monokai">Monokai</option>
              <option value="ace/theme/terminal">Terminal</option>
              <option value="ace/theme/chrome">Chrome</option>
              <option value="ace/theme/xcode">Xcode</option>
              <option value="ace/theme/textmate">Textmate</option>
              <option value="ace/theme/sqlserver">Sqlserver</option>
              <option value="ace/theme/eclipse">Eclipse</option>
            </select>
            <br>
            

          </div>
          
            <div id="editor"></div>
            

    </div>
          <button id="sendresult" class="button button1" type="button"  ></button>
          <button id="sendTaskShow" class="button button1" type="button"></button>

          <button id="submit" class="button button1" type="button" name="Run" onclick="HTML()">Futtatás</button>
          <input id="check" onchange="check(this)" type="checkbox" value="check" style="font-size:30px">
          <label for="check" id="input-test" style="font-size:20px">Bemeneti értékek</label>
          <br/> 
        <!--       <textarea id="input" name="input" rows="6" cols="20" style="display: block; width: auto; height: auto;"></textarea>
-->
       <textarea id="input" name="input" rows="6" cols="20"></textarea> 
      
          
      <pre id="process"></pre>
       
      <pre id="output"></pre>

      
        
		 <br><br>
    </div>
  </body>
  <script>
    var language = {};
/*
var ajax = new XMLHttpRequest();
ajax.open("GET", "data.php", true);
ajax.send();

ajax.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
      console.log(this.responseText);
      var data = JSON.parse(this.responseText);
      
        var elso =  data[0].langCompilareInfo;
        language["cpp"] = elso;
        var m =  data[1].langCompilareInfo;
       
        



      
    }

};
*/

//ez van a compilatorba kezteben

language["cpp"] ="";

language["c"] ="";

language["java"] ="";

  var EditSession = require("ace/edit_session").EditSession;
  var mode = {};
  mode["cpp"] = ace.createEditSession(language["cpp"]);
  mode["java"] = ace.createEditSession(language["java"]);
  mode["c"] = ace.createEditSession(language["c"]);

function setupEditor() {
  var config = require("ace/config");
  config.init();
  document.getElementById('output').value="";
  document.getElementById('theme').value="ace/theme/cobalt";
  document.getElementById('modes').value="ace/mode/c_cpp";
  window.editor = ace.edit("editor");
  editor.getSession().setUseWorker(false);
  editor.setOptions({
    autoScrollEditorIntoView: true,
    wrap:true,
    copyWithEmptySelection: false,
    animatedScroll: true,
    fontSize:16,
    enableBasicAutocompletion: true,
    enableLiveAutocompletion: true,
    enableSnippets: false,
  });
  let w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
  if(w<600){
	  editor.setOptions({
    enableBasicAutocompletion: false,
    enableLiveAutocompletion: false
  });
  }
  editor.getSession().setMode(document.getElementById('modes').value);
  editor.setTheme("ace/theme/cobalt");
  editor.setValue(language["cpp"],1);
	editor.commands.addCommand({
	    name: 'increasefontsize',
	    bindKey: {win: 'Ctrl-+',  mac: 'Command-+'},
	    exec: function(editor) {
	    
		let fontp = editor.getFontSize();
		fontp = ((fontp + 2) > 30 ?30:(fontp+2));
		editor.setFontSize(fontp);
		editor.resize();
	    }
	 });
	 editor.commands.addCommand({
	    name: 'decreasefontsize',
	    bindKey: {win: 'Ctrl--',  mac: 'Command--'},
	    exec: function(editor) {
	    
		let fontp = editor.getFontSize();
		fontp = ((fontp - 2) < 12 ?12:(fontp-2));
		editor.setFontSize(fontp);
		editor.resize();
	    }
	 });
	 
  }
  function ready() {
    setupEditor();

    document.getElementById('check').checked=false;


  }


  function changeMode() {
       
      let x = document.getElementById('modes');
      let lang = x.options[x.selectedIndex].text;
      editor.setSession(mode[lang]);
      editor.getSession().setMode(document.getElementById('modes').value);
      editor.setValue(language[lang],1);
      editor.setOptions({
        autoScrollEditorIntoView: true,
        wrap:true,
        copyWithEmptySelection: false,
        animatedScroll: true,
        fontSize:16,
        enableBasicAutocompletion: true,
        enableLiveAutocompletion: true,
        enableSnippets: false,
      });
      
	  let w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
  if(w<600){
	  editor.setOptions({
    enableBasicAutocompletion: false,
    enableLiveAutocompletion: false
  });
  }
  }
  function changeTheme() {
    editor.setTheme(document.getElementById('theme').value);
  }

  function check(checkbox){
    let input = document.getElementById('input');
    if(checkbox.checked == true){
      input.style.display="block";


    }
    else {input.style.display="none";input.value="";}
  }
  function HTML(){
    var output = document.getElementById("output");
    let x = document.getElementById('modes');
    var buttn = document.getElementById('submit');
    var proD = document.getElementById("process");
    proD.innerHTML ="Uploading....";
    window.scrollTo(0,window.innerHeight);
    output.innerHTML="";
    output.style.display="none";
    let lang = x.options[x.selectedIndex].text;
    var text = editor.getValue();

    var input = (document.getElementById('input').value==="")?" ":document.getElementById('input').value;
    var formData = new FormData();
    formData.append("text", text);
    formData.append("input", input);
    formData.append("language", lang);
    console.log(lang);
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if(this.readyState == 1 || this.readyState == 2 || this.readyState == 3){proD.innerHTML = "Betöltés....";}
      else if(this.readyState == 4 && this.status == 200) {
        console.log(text);
        proD.innerHTML = "";
        output.innerHTML = this.responseText;
        
        if(text == ""){
          document.querySelector('#buttn').disabled = true;

        }

	      output.style.display = "block";

        var finalOutput = this.responseText.replace("<b>","");
        var finalOutput2 = finalOutput.replace("</b>","");

        var url_string = window.location.href;
        var url = new URL(url_string);
        var pageId = url.searchParams.get("pageid");
        var pageName = url.searchParams.get("pagename");
       console.log(this.responseText);
       var sendresul = document.getElementById("sendresult");
        var a = document.createElement('a');
        var linkText = document.createTextNode("Elkuldés");
        var sendTaskS = document.getElementById("sendTaskShow");

       

        a.appendChild(linkText);
        a.title = "Akkor küld be ha biztos jo mert csak 3 probalkozásod van a 3 fájlra!";

        a.href = "taskItemResult.php?pageid="+pageId +"&pagename="+pageName+"&eredmeny="+finalOutput2+"&bemenet="+input+"&lang="+lang;
        a.setAttribute('target', '_blank');
        sendresul.appendChild(a);
       
        //miutan raklikkel az elkuldesre az elkuldes link eltunjon
        buttn.addEventListener('click', () => {
          a.style.display = 'none';
          
        });
        
        a.addEventListener('click', () => {

          a.style.display = 'none';
          
          
        });
        //ha harom probalkozas utan eltunik a bekuldes
        var count =0;
        $('#sendresult').on('click',function(){

          count = count +1;
          if(count == 3){
          $('#sendresult').hide();
          //ide beteszuk meg egy linket s inen lehet megnyitom a feladatimat s kipistazom a feladati pot szamoat
          $('#sendTaskShow').show();
          var linkTask = document.createElement('a');
          var linkTextTask = document.createTextNode("Feladataim megtekintése");
          linkTask.appendChild(linkTextTask);
          linkTask.href="taskResultShow.php";
          linkTask.setAttribute('target', '_blank');
          sendTaskS.appendChild(linkTask);
          linkTask.addEventListener('click', () => {
            linkTask.style.display = 'none';});
            buttn.addEventListener('click', () => {
            linkTask.style.display = 'none';
          
        });
          }});
        
        
         
        

       
        
      }
      

    };
	xmlhttp.open("POST", "compiler.php", true);
//	xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded' );
	xmlhttp.send(formData);

  }
     
    
        
  
  var file = {};
  file["cpp"] = "cpp";
  file["java"] = "java";
  file["c"] = "c";
  
  function download() {
	let x = document.getElementById('modes');
	let lang = x.options[x.selectedIndex].text;
      var filename = "Main." + file[lang];
      var text = editor.getValue();
      var element = document.createElement('a');
      element.setAttribute('href', 'data:text/html;charset=utf-8,' + encodeURIComponent(text));
      element.setAttribute('download', filename);
      element.style.display = 'none';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }
    
  function upload(){
      var element = document.createElement('input');
      element.setAttribute('type', 'file');
      element.setAttribute('id', 'file_1');
      element.style.display = 'none';
      document.body.appendChild(element);
      element.click();
      let file_1 = document.getElementById('file_1');
      file_1.addEventListener('change', (event) => {
    	const fileList = event.target.files;
    	//console.log(fileList);
    	//console.log(fileList[0].name);
    	let type = fileList[0].name;
       let x = document.getElementById('modes');
	let lang = x.options[x.selectedIndex].text;
    	var patt = new RegExp("\."+file[lang]+"$");
    	//console.log(patt);
    	if(patt.test(type)){
    		let reader = new FileReader();
  		reader.readAsText(fileList[0]);
  		reader.onload = function() {
    			//console.log(reader.result);
    			editor.setValue(reader.result,1);
  		};
    	}
    	else alert("Nem megfelelő fájl!!! fájlnak rendelkeznie kell ."+file[lang]+" kiterjesztéssel");
  	},document.body.removeChild(element));
      
  	
  }

  </script>
</html>
