<?php 
//pseude kod fajl letoltese
if(!empty($_GET['file'])){
    $fileName  = basename($_GET['file']);
    $filePath  = "pseudeCode/".$fileName;
    
    if(!empty($fileName) && file_exists($filePath)){
        //define header
        header("Cache-Control: public");
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$fileName");
        header("Content-Type: application/zip");
        header("Content-Transfer-Encoding: binary");
        
        //read file 
        readfile($filePath);
        exit;
    }
    else{

        echo "file not exit";
    }
}
//a 3 nyelven levo zipp letoltese
if(!empty($_GET['zipFile'])){
    $fileName  = basename($_GET['zipFile']);
    $filePath  = "solveCode/".$fileName;
    
    if(!empty($fileName) && file_exists($filePath)){
        //define header
        header("Cache-Control: public");
        header("Content-Description: File Transfer");
        header("Content-Disposition: attachment; filename=$fileName");
        header("Content-Type: application/zip");
        header("Content-Transfer-Encoding: binary");
        
        //read file 
        readfile($filePath);
        exit;
    }
    else{

        echo "file not exit";
    }
}


?>