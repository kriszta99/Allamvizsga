
<?php 
include("navbar2.php");
?>
<!DOCTYPE html>

<html lang="hu">
    <head>
        <meta charset="utf-8">

        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>

        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/taskItemShow.css">
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <title>Task</title>


    </head>
    <body>
      
    <div class="overflow-scroll">

    <div class="column text-center" id="itemShow" >
      <p>
          <?php echo getTaskTItemShohwItem($_GET['pageid']);?>
      

      <?php echo dropdownTestTaskValue($_GET['pageid']);?>
      </p>
      <?php echo getPseudeCodeFileFilterTask($_GET['pageid']);?>  
      <?php echo getZipFileTask($_GET['pageid']);?>
      
      

      
     
          
                 
      
      
        
  </div>

</div>
  </div>
  <br class="newLine"><br>
    <div class="column" >
    <?php include("editor.php")?>

    </div>

    </body>
<script>
  Swal.fire({
        icon: 'info',
        iconColor:"#bc8f8f",
        title: 'Letöltés és fordítóprogram!',
        text: 'Ha újratöltöd az oldalt elindul újra a viiszaszámláló s a fordítóprogramban lévő kód is amit eddig beírtál is eltünik! ',
        confirmButtonColor: '#bc8f8f',

        })
  /*A letolteshez viiszaszmol 900 masodpercet*/
  jQuery(document).ready(function() {
var sec = 900
var timer = setInterval(function() {
   $("#mdtimer span").text(sec--);
   if (sec == 0) {
$("#makingdifferenttimer").delay(1000).fadeIn(1000);
$("#mdtimer").hide(1000) .fadeOut(fast);}
},1000);
});
/*
document.onkeydown = function() {    
    switch (event.keyCode) { 
        case 116 : //F5 button
            event.returnValue = false;
            event.keyCode = 0;
            return false; 
        case 82 : //R button
            if (event.ctrlKey) { 
                event.returnValue = false; 
                event.keyCode = 0;  
                return false; 
            } 
    }
}
*/
</script>
</script>    
</style>
</html>  
