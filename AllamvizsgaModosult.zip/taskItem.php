<?php 
include("navbar2.php");
include("editor.php");

?>
