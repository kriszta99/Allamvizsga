// 'Ctrl +' megnöveli a betűtípus méretét
// 'Ctrl -' lecsökkenti a betűtípus méretét

public class Main {
 	public static void main(String[] args) { 
		int myNum;
		 myNum = 15;
		 System.out.println(myNum);
	}
}