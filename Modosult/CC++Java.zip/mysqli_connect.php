<?php
$cone =mysqli_connect('localhost','krisztina', 'admin', 'krisztina');

if(!$cone){
    echo "Database connection failed....";
}
   
?>