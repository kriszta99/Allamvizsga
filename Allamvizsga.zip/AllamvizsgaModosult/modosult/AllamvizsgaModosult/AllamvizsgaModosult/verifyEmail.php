<?php  include("navbar.php")?>
<?php include ("login-register-link-bootstap.php")?>
<?php include_once ("controller.php"); ?>


<!doctype html>
<html lang="hu">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/style.css">

</head>
    <title>Kód ellenőrzés</title>
</head>

<body >
<div id='container'>    
<div  class="was-validated">
    <div class="d-flex justify-content-center align-items-center login-container"  >
       <div id='line'>
         <form class="login-form text-center" method="post" action="verifyEmail.php" autocomplete="off" >
            <h1 class="mb-5 font-weight-light text-uppercase">Email cím elleőrzés</h1>
            <?php
            if(isset($_SESSION['message'])){
                ?>
                <div id="alert"><?php echo $_SESSION['message']; ?></div>
                <?php
            }
            ?>

            <?php
            if($errors > 0){
                foreach($errors AS $displayErrors){
                ?>
                <div id="alert"><?php echo $displayErrors; ?></div>
                <?php
                }
            }
            ?>
            <div class="form-group">
                <input type="text" minlength="6"  maxlength="6" pattern=".{6}" name="OTPverify" placeholder="6 darab szám kell"  class="form-control rounded-pill form-control-lg"  
                required
                oninvalid="this.setCustomValidity('Minimum 6 szám kell')"
                oninput="this.setCustomValidity('')"/>
                
                <div class="valid-feedback">Van 6 szám.</div>
            </div>
           
            
            <button type="submit" name="verifyEmail"  class="btn mt-5 rounded-pill btn-lg btn-custom btn-block text-uppercase">Ellenőrzés</button>
            
        </form>
        </div>
        </div>  
    </div>
</div>

  
</body>
<script>
  
</script>

</html>