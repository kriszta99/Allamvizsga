<?php
session_start();

include("navbar2.php");
include("login-register-link-bootstap.php");


?>

<!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="css/style.css">
<link rel="stylesheet" href="css/home.css">


</head>
<style>


</style>
<body>
	<p class="welcome-page">Üdvözöljük  <?php echo $_SESSION['firstName'];?>&nbsp<?php  echo $_SESSION['lastName']; ?></p>
	<br>
	<?php 	getProgramingLaunguageIcon();
 ?>


</body>
</html>