var ajax = new XMLHttpRequest();
ajax.open("GET", "data.php", true);
ajax.send();

ajax.onreadystatechange = function() {
  if (this.readyState == 4 && this.status == 200) {
      console.log(this.responseText);
      var data = JSON.parse(this.responseText);
      console.log(data);
      for(var a = 0; a < data.length; a++) {
        var compilareI = data[a].langCompilareInfo;
        console.log(compilareI);
        var elso =  data[0].langCompilareInfo
        
  }
}

};

//ez van a compilatorba kezteben
var language = {};

language["cpp"] ="";
language["java"] ="";
language["c"] = "";

  var EditSession = require("ace/edit_session").EditSession;
  var mode = {};
  mode["cpp"] = ace.createEditSession(language["cpp"]);
  mode["java"] = ace.createEditSession(language["java"]);
  mode["c"] = ace.createEditSession(language["c"]);

function setupEditor() {
  var config = require("ace/config");
  config.init();
  document.getElementById('output').value="";
  document.getElementById('theme').value="ace/theme/cobalt";
  document.getElementById('modes').value="ace/mode/c_cpp";
  window.editor = ace.edit("editor");
  editor.getSession().setUseWorker(false);
  editor.setOptions({
    autoScrollEditorIntoView: true,
    wrap:true,
    copyWithEmptySelection: false,
    animatedScroll: true,
    fontSize:16,
    enableBasicAutocompletion: true,
    enableLiveAutocompletion: true,
    enableSnippets: false,
  });
  let w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
  if(w<600){
	  editor.setOptions({
    enableBasicAutocompletion: false,
    enableLiveAutocompletion: false
  });
  }
  editor.getSession().setMode(document.getElementById('modes').value);
  editor.setTheme("ace/theme/cobalt");
  editor.setValue(language["cpp"],1);
	editor.commands.addCommand({
	    name: 'increasefontsize',
	    bindKey: {win: 'Ctrl-+',  mac: 'Command-+'},
	    exec: function(editor) {
	    
		let fontp = editor.getFontSize();
		fontp = ((fontp + 2) > 30 ?30:(fontp+2));
		editor.setFontSize(fontp);
		editor.resize();
	    }
	 });
	 editor.commands.addCommand({
	    name: 'decreasefontsize',
	    bindKey: {win: 'Ctrl--',  mac: 'Command--'},
	    exec: function(editor) {
	    
		let fontp = editor.getFontSize();
		fontp = ((fontp - 2) < 12 ?12:(fontp-2));
		editor.setFontSize(fontp);
		editor.resize();
	    }
	 });
	 
  }
  function ready() {
    setupEditor();
    document.getElementById('check').checked=false;
  }


  function changeMode() {
       
      let x = document.getElementById('modes');
      let lang = x.options[x.selectedIndex].text;
      editor.setSession(mode[lang]);
      editor.getSession().setMode(document.getElementById('modes').value);
      editor.setValue(language[lang],1);
      editor.setOptions({
        autoScrollEditorIntoView: true,
        wrap:true,
        copyWithEmptySelection: false,
        animatedScroll: true,
        fontSize:16,
        enableBasicAutocompletion: true,
        enableLiveAutocompletion: true,
        enableSnippets: false,
      });
      
	  let w = window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth;
  if(w<600){
	  editor.setOptions({
    enableBasicAutocompletion: false,
    enableLiveAutocompletion: false
  });
  }
  }
  function changeTheme() {
    editor.setTheme(document.getElementById('theme').value);
  }

  function check(checkbox){
    let input = document.getElementById('input');
    if(checkbox.checked == true){
      input.style.display="block";
    }
    else {input.style.display="none";input.value="";}
  }
  function HTML(){
    var output = document.getElementById("output");
    let x = document.getElementById('modes');
    var buttn = document.getElementById('submit');
    //buttn.disabled = true;
    var proD = document.getElementById("process");
    proD.innerHTML ="Uploading....";
    window.scrollTo(0,window.innerHeight);
    output.innerHTML="";
    output.style.display="none";
    let lang = x.options[x.selectedIndex].text;
    var text = editor.getValue();
    var input = (document.getElementById('input').value==="")?" ":document.getElementById('input').value;
    var formData = new FormData();
    formData.append("text", text);
    formData.append("input", input);
    formData.append("language", lang);
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
      if(this.readyState == 1 || this.readyState == 2 || this.readyState == 3){proD.innerHTML = "Betöltés....";}
      else if(this.readyState == 4 && this.status == 200) {
        proD.innerHTML = "";
        output.innerHTML = this.responseText;
	output.style.display = "block";
        //console.log(this.responseText);
        window.scrollTo(0,window.innerHeight);
        //buttn.disabled = false;
      }
    };
	xmlhttp.open("POST", "compiler.php", true);
	//xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded' );
	xmlhttp.send(formData);

  }
  var file = {};
  file["cpp"] = "cpp";
  file["java"] = "java";
  file["c"] = "c";
  function download() {
	let x = document.getElementById('modes');
	let lang = x.options[x.selectedIndex].text;
      var filename = "Main." + file[lang];
      var text = editor.getValue();
      var element = document.createElement('a');
      element.setAttribute('href', 'data:text/html;charset=utf-8,' + encodeURIComponent(text));
      element.setAttribute('download', filename);
      element.style.display = 'none';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    }
    
  function upload(){
      var element = document.createElement('input');
      element.setAttribute('type', 'file');
      element.setAttribute('id', 'file_1');
      element.style.display = 'none';
      document.body.appendChild(element);
      element.click();
      let file_1 = document.getElementById('file_1');
      file_1.addEventListener('change', (event) => {
    	const fileList = event.target.files;
    	//console.log(fileList);
    	//console.log(fileList[0].name);
    	let type = fileList[0].name;
       let x = document.getElementById('modes');
	let lang = x.options[x.selectedIndex].text;
    	var patt = new RegExp("\."+file[lang]+"$");
    	//console.log(patt);
    	if(patt.test(type)){
    		let reader = new FileReader();
  		reader.readAsText(fileList[0]);
  		reader.onload = function() {
    			//console.log(reader.result);
    			editor.setValue(reader.result,1);
  		};
    	}
    	else alert("Unappropriate file !!! file must have ."+file[lang]+" extension");
  	},document.body.removeChild(element));
      
  	
  }
