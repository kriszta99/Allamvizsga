<?php include ("login-register-link-bootstap.php")?>
<?php include_once ("controller.php"); ?>

<!doctype html>
<html lang="hu">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="css/style.css">

</head>
    <title>Új jelszó megadása</title>
</head>
<div id="container">

<div  class="was-validated">
    <div class="d-flex justify-content-center align-items-center login-container"  >
    <div id="line"></div>
    <form class="login-form text-center" method="post" action="resetPassword.php" autocomplete="off" >
            
        <h1 class="mb-5 font-weight-light text-uppercase">Új jelszó megadása</h1>
        
        <?php
            if(isset($_SESSION['message'])){
                ?>
                <div id="alert"><?php echo $_SESSION['message']; ?></div>
                <?php
            }
            ?>
            <?php
            if ($errors > 0) {
                foreach ($errors as $displayErrors) {
            ?>
                    <div id="alert"><?php echo $displayErrors; ?></div>
            <?php
                }
            }
            ?>
            <br>
            <div class="form-group">
                <input type="password" minlength="8" maxlength="15" name="newPassword" id="newPassword" class="form-control rounded-pill form-control-lg pwds" placeholder="Új jelszó" required
                oninvalid="this.setCustomValidity('Minimum 8 karakter kell')"
                oninput="this.setCustomValidity('')"/>
                
                <div class="valid-feedback">Van 8 karakter.</div>

            </div>
            
            <div class="form-group">
                <input type="password" minlength="8" maxlength="15" name="confirmPassword" id="confirmPassword"  class="form-control rounded-pill form-control-lg pwds" placeholder="Jelszó megerősítés" required
                oninvalid="this.setCustomValidity('Minimum 8 karakter kell')"
                oninput="this.setCustomValidity('')"/>
                <div class="valid-feedback">Van 8 karakter.</div>


            </div>

            <br>
            
            <input type="submit" name="resetPassword" value="Jelszó megváltoztatása" class="rounded-pill btn-lg btn-custom btn-block text-uppercase">


            
        </form>
    </div>
</div>          
</body>
<script>
     
</script>

</html>