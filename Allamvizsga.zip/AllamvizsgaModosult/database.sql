/*Felhasznalao tabla*/
 CREATE TABLE users(

     userId int not null AUTO_INCREMENT PRIMARY KEY,
     firstName varchar(100),
     lastName varchar(100),
     UserEmail varchar(200) not null ,
     userPassword varchar(200) not null ,
     registerDate datetime,
     code int(6) not null 


 );
/*Programozasi technikak tabla*/
 CREATE TABLE categories(
     categorieId int not null AUTO_INCREMENT PRIMARY KEY,
     categorieName varchar(100) not null
    

 );
INSERT INTO categories (categorieName) VALUES ('Oszd meg és uralkodj');
INSERT INTO categories (categorieName) VALUES ('Visszalépéses keresés');
INSERT INTO categories (categorieName) VALUES ('Mohó módszer');
INSERT INTO categories (categorieName) VALUES ('Dinamikus programozás');
INSERT INTO categories (categorieName) VALUES ('Elágazás és korlátozás');
/*fooldalom megjeletio*/
 CREATE TABLE homepage(
	homepageId int PRIMARY KEY AUTO_INCREMENT,
    homepageName varchar(100) not null,
    homepageDescript varchar(255) not null
);
/*Kepek*/
 CREATE TABLE pictures(
     pictureId int not null AUTO_INCREMENT PRIMARY KEY,
     homepageId int,
	 pictureName varchar(100),
     pictureNine varchar(150),
     FOREIGN KEY (homepageId) REFERENCES homepage(homepageId)

 ); 

 INSERT INTO homepage(homepageName,homepageDescript) VALUES ('fiok','Szeretnél minél több programozási feladatot megoldani?
De nincs még fiókod?Regisztrálj!');
 INSERT INTO homepage(homepageName,homepageDescript) VALUES ('nyelv_icon','Ezeken a programozási nyelveken oldhatod/írhatod meg a feladatokat:'); 
  INSERT INTO homepage(homepageName,homepageDescript) VALUES ('logo','');
 INSERT INTO homepage (homepageName,homepageDescript) VALUES ('fiok','Kattints ide');
   
INSERT INTO pictures(homepageId,pictureName,pictureNine) VALUES(1,'regisz','icon/regisz.jpg');
INSERT INTO pictures(homepageId,pictureName,pictureNine) VALUES(2,'c++','icon/c++.jpg');
INSERT INTO pictures(homepageId,pictureName,pictureNine) VALUES(2,'c','icon/c.jpg');
INSERT INTO pictures(homepageId,pictureName,pictureNine) VALUES(2,'java','icon/java.jpg');
INSERT INTO pictures(homepageId,pictureName,pictureNine) VALUES(3,'logo','icon/logo.png');
/*programozasi nyelvek tabla megoldashoz es a tesztfilekhez kell */
CREATE TABLE prog_language(
    prog_langId int not null AUTO_INCREMENT PRIMARY KEY,
    langName varchar(25),
    langCompilareInfo varchar(400)

);
INSERT INTO prog_language(langName,langCompilareInfo)VALUES('c++',"\n// 'Ctrl +' megnöveli a betűtípus méretét\n// 'Ctrl -' lecsökkenti a betűtípus méretét\n\n#include <iostream>\nusing namespace std;\n\nint main() {\n\tint num;\n\tcin >> num;\t\t\t//Bemenet beolvasása (STDIN)\n\tcout << \"Kimeneti szám: \" << num << endl;\t// Kimenet kiirása(STDOUT)\n}\n\n\n//Írd ide a saját kódódat!");
INSERT INTO prog_language(langName,langCompilareInfo)VALUES('c',"\n// 'Ctrl +' megnöveli a betűtípus méretét\n// 'Ctrl -' lecsökkenti a betűtípus méretét\n\n#include <stdio.h>\n\nint main() {\n\tint num;\n\tscanf(\"%d\",&num);\t\t\t// Bemenet beolvasása (STDIN)\n\tprintf(\"Kimeneti szám:  %d\",num);\t//Kimenet kiirása(STDOUT)\n\treturn 0;\n}\n\n\n//Írd ide a saját kódódat!");
INSERT INTO prog_language(langName,langCompilareInfo)VALUES('java',"\n// 'Ctrl +' megnöveli a betűtípus méretét\n// 'Ctrl -' lecsökkenti a betűtípus méretét\n\npublic class Main {\n \tpublic static void main(String[] args) { \n\t\tint myNum;\n\t\t myNum = 15;\n\t\t System.out.println(myNum);\n\t}\n}");
INSERT INTO prog_language(langName,langCompilareInfo)VALUES('pseudo',null);
/*Nehezsegi szint*/
 CREATE TABLE difficultylevel(
     lavelId int not null AUTO_INCREMENT PRIMARY KEY,
     LavelName varchar(15)


 );
INSERT INTO difficultylevel(LavelName) VALUES("könnyű");
INSERT INTO difficultylevel(LavelName) VALUES("közép");
INSERT INTO difficultylevel(LavelName) VALUES("nehéz");

 /*Feladatok tabla*/
 CREATE TABLE Tasks(
     task_id int not null AUTO_INCREMENT PRIMARY KEY,
     taskTitle varchar(50) not null,
     taskText varchar(800) not null,
     categorieId int,
     lavelId int,
     FOREIGN KEY (categorieId) REFERENCES categories(categorieId),
     FOREIGN KEY (lavelId) REFERENCES difficultyLevel(lavelId)
);
INSERT INTO tasks(taskTitle,taskText,categorieId,lavelId) VALUES ("Hatvány","Írj egy algoritmust az „Oszd meg és urald” programozási technikával az a n -en kiszámítására.",1,1);
INSERT INTO tasks(taskTitle,taskText,categorieId,lavelId) VALUES ("Maximumkeresés","Adott egy számsorozat, amelyet az a[1..n]
tömbben tároltunk. Határozzuk meg a legnagyobb elem indexét!",1,1);
/*Megoldasi  tipusok fajl tabla*/
CREATE TABLE Solution(
    solpeId int not null AUTO_INCREMENT PRIMARY KEY,
    SolutionFile varchar(1000),
    task_id int,
    prog_langId int,
    FOREIGN KEY (task_id) REFERENCES Tasks(task_id),
    FOREIGN KEY (prog_langId) REFERENCES prog_language(prog_langId)
);



 