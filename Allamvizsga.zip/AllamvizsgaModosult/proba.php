<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

</style>
</head>
<body>


<div class="row">
    
  <div class="column" id="itemShow" >
    <h2>Column 1</h2>
    <p>
</div>
  <div class="column" >
    
    <?php include("editor.php")?>
  </div>
</div>

</body>
</html>
