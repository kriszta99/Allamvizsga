
<?php 
include("navbar2.php");

?>
<!DOCTYPE html>

<html lang="hu">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="css/taskItemShow.css">

        <title>Task</title>


    </head>
    <body >
    <div class="row data-mdb-perfect-scrollbar='true' ">
    
    <div class="column text-center" id="itemShow" >
      <p>
          <?php echo getTaskTItemShohwItem($_GET['pageid']);?>
      </p>
  </div>
    <div class="column" >
      
      <?php include("editor.php")?>
    </div>
  </div>
  
    </body>
    
</style>
</html>    