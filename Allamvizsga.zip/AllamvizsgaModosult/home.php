<?php
include("navbar.php");
include ("login-register-link-bootstap.php");
?>

<!doctype html>
<html lang="hu">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Főoldal</title>
    <link rel="stylesheet" href="css/home.css">

</head>

    </head>
    <body class="homepage">
        
        <?php 
        getHomePageRegistration();
    
        getProgramingLaunguageIcon();
        
        ?>
     <br><br>   
    </body>
</html>